use master 
go 
create database DefuncionGeneral 

go 
use DefuncionGeneral
go 

create table sexo(
id_sexo int identity not null, 
Sexo varchar(15)
primary key (id_sexo)
)

create table estado_civil(
id_estado int identity not null,
Estado_civil varchar (40)
primary key (id_estado)
)



create table nivel_instruccion(
id_nivel int identity not null, 
nivel varchar(40), 
primary key (id_nivel)
)

create table autoidentificacion (
id_autoid int identity not null, 
Autoidentificacion varchar (40) not null
primary key (id_autoid)

)

create table Lugar_falleci(
id_lugar_falle int identity not null, 
Lugar varchar (50) not null, 
primary key(id_lugar_falle)
)



create table Mor_Materna(
id_morma int identity not null, 
PeriodoMuerte varchar (60) not null, 
primary key (id_morma)
)



create table muerte_acc_vio(
id_muerte int identity not null, 
tipo varchar (40) not null, 
primary key (id_muerte)
)

create table lugar_muerte_violenta(
id_lug int identity not null, 
Lugar varchar (50) not null, 
primary key (id_lug) 
)



create table provincias(
id_provincia int identity not null, 
Provincia varchar(50) not null, 
primary key (id_provincia)
)

create table cabe_form(
num_form int not null, 
of_regis varchar (40) not null, 
id_provincia int not null,
canton varchar (50) not null,
parroquia varchar (50), 
fecha_ins date not null, 
dpa numeric (6) not null, 
num_of_reg int not null, 
fecha_dpa date not null, 
acta_inscripcion numeric (15) unique not null, 
primary key (num_form),
foreign key (id_provincia) references provincias (id_provincia)
)



create table datos_fallecido(
id_datos int not null,
num_form int unique not null,/**/
nom_apel varchar (80) not null, 
nacionalidad int check (nacionalidad > 0 and nacionalidad < 3) not null, 
Pais_Origen varchar (60),
CI varchar(13) not null, 
id_sexo int not null, /**/
fecha_nacimiento date not null, 
fecha_fallecimiento date not null, 
enHoras numeric(2), 
enDias numeric(2), 
enMeses numeric(2), 
AniosCumplidos numeric(3), 
id_provincia int not null, /**/
Canton varchar(40) not null, 
parroquia varchar(50) not null, 
Localidad varchar (50), 
Direccion_domici varchar (60),
dpa numeric (6) not null, 
localidad_DPA numeric(3) not null, 
id_estado int not null, /**/
leer_escribir bit not null,
id_nivel int not null, /**/
id_autoidentificacion int not null, /**/ 
id_lugar_muerte int not null,/**/
primary key (id_datos),
foreign key (num_form) references cabe_form (num_form), 
foreign key (id_sexo) references sexo (id_sexo), 
foreign key (id_provincia) references provincias (id_provincia), 
foreign key (id_nivel) references nivel_instruccion (id_nivel),
foreign key (id_autoidentificacion) references autoidentificacion (id_autoid),
foreign key (id_lugar_muerte) references Lugar_falleci (id_lugar_falle), 
foreign key (id_estado) references estado_civil (id_estado)
)



create table info_lugar(
id_infor_lugar int identity not null, 
id_lugar_muerte int not null, /**/
Nom_lugar varchar (50) not null, 
id_provincia int not null, /**/
Canton varchar (50) not null, 
Parroquia varchar (50), 
Localidad varchar (50), 
Direccion varchar (50),
telefono varchar (12), 
dpa numeric (6) not null, 
localidad_DPA numeric(3) not null,
primary key (id_infor_lugar),
foreign key (id_lugar_muerte) references Lugar_falleci (id_lugar_falle),
foreign key (id_provincia) references provincias (id_provincia)
)





create table certif_def (
id_cert int identity not null, 
num_form int unique not null,/**/
causaA varchar (80) not null, 
causaB varchar (80), 
causaC varchar (80), 
causaD varchar (80), 
tiempoA int not null, 
tiempoB int, 
tiempoC int, 
tiempoD int, 
codigoA int not null, 
codigoB int, 
codigoC int,
codigoD int, 
otraCausa varchar (100), 
tiempoOtraCausa int, 
cod_causa_basi numeric (4), 
id_morma int,/**/ 
id_muerte int,/**/ 
id_lug int, /**/
descripcion varchar (300), 
autopsia bit not null, 
primary key (id_cert), 
foreign key (num_form) references cabe_form (num_form),
foreign key (id_morma) references Mor_Materna (id_morma), 
foreign key (id_muerte) references muerte_acc_vio (id_muerte), 
foreign key (id_lug) references lugar_muerte_violenta (id_lug)
)


create table muerte_NO_cert(
id_NOcert int identity not null, 
num_form int unique not null, 
CausaProb varchar (100), 
Sintomas varchar (400),
Nom_apel_Testigo1 varchar  (50), 
Nom_apel_Testigo2 varchar (50), 
Dir_tes1 varchar (50), 
Dir_tes2 varchar (50), 
telf_tes1 varchar (13), 
telf_tes2 varchar (13), 
primary key (id_NOcert), 
foreign key (num_form) references cabe_form (num_form)
)

create table certificador(
id_certificador int identity not null, 
tipo varchar (50) not null, 
primary key (id_certificador)
)

create table parentes(
id_paren int identity not null, 
parentesco varchar (50) not null,
primary key (id_paren)
)

create table datos_def (
id_datos_def int identity not null, 
num_form int unique not null, /**/
id_certificador int not null, /**/
Nom_apel_certificador varchar (50) not null, 
CI_Certificador varchar (13) not null, 
Direccion_Certificador varchar (50) not null,
telefono varchar (13), 
Nom_apel_solicita varchar (50) not null, 
edad int not null check (edad > 0 and edad <130),
id_paren int not null, /**/
Observaciones varchar (400), 
primary key (id_datos_def), 
foreign key (num_form) references cabe_form (num_form),
foreign key (id_certificador) references certificador (id_certificador),
foreign key (id_paren) references parentes (id_paren)
)








/*select * from cabe_form
select * from provincias
select * from estado_civil
select * from nivel_instruccion
select * from autoidentificacion
select * from Lugar_falleci*/





/*Tabla PROVINCIAS*/

insert into provincias values ('Galapagos');
insert into provincias values ('Carchi'); 
insert into provincias values ('Imbabura'); 
insert into provincias values ('Pichincha'); 
insert into provincias values ('Cotopaxi'); 
insert into provincias values ('Tungurahua'); 
insert into provincias values ('Bolivar'); 
insert into provincias values ('Chimborazo'); 
insert into provincias values ('Ca�ar'); 
insert into provincias values ('Azuay'); 
insert into provincias values ('Loja'); 
insert into provincias values ('Sto. Domingo de los Tsachilas'); 
insert into provincias values ('Sucumbios'); 
insert into provincias values ('Napo'); 
insert into provincias values ('Pastaza'); 
insert into provincias values ('Orellana'); 
insert into provincias values ('Morona Santiago'); 
insert into provincias values ('Zamora Chinchipe'); 
insert into provincias values ('Esmeraldas'); 
insert into provincias values ('Manabi'); 
insert into provincias values ('Guayas'); 
insert into provincias values ('Los Rios');
insert into provincias values ('El Oro'); 
insert into provincias values ('Santa Elena'); 

/*Tabla Sexo*/

insert into sexo values('Hombre'); 
insert into sexo values('Mujer');

/*Tabla ESTADO CIVIL*/

insert into estado_civil values('Unido(a)');
insert into estado_civil values('Soltero(a)');
insert into estado_civil values('Casado(a)');
insert into estado_civil values('Divorciado(a)');
insert into estado_civil values('Separado(a)');
insert into estado_civil values('Viudo(a)');

/*Tabla NIVEL DE INSTRUCCION*/

insert into nivel_instruccion values ('Ninguno'); 
insert into nivel_instruccion values ('Centro de alfabetizacion'); 
insert into nivel_instruccion values ('Primaria'); 
insert into nivel_instruccion values ('Secundaria'); 
insert into nivel_instruccion values ('Educacion Basica'); 
insert into nivel_instruccion values ('Educacion Media/Bachillerato'); 
insert into nivel_instruccion values ('Ciclo posbachillerato'); 
insert into nivel_instruccion values ('Superior'); 
insert into nivel_instruccion values ('Posgrado'); 

/*Tabla AUTOIDENTIFICACION*/

insert into autoidentificacion values ('Indigena'); 
insert into autoidentificacion values ('Afoecuatoriano(a) Afordescendiente');
insert into autoidentificacion values ('Negro(a)');
insert into autoidentificacion values ('Mulato(a)');
insert into autoidentificacion values ('Montubio(a)');
insert into autoidentificacion values ('Mestizo(a)');
insert into autoidentificacion values ('Blanco(a)');
insert into autoidentificacion values ('Otra');

/*Tabla LUGAR DE FALLECIMIENTO*/

insert into Lugar_falleci values('Establecimiento del Ministerio de Salud');
insert into Lugar_falleci values('Establecimiento del IESS');
insert into Lugar_falleci values('Establecimiento de la Junta Bancaria');
insert into Lugar_falleci values('Otro establecimiento Publico');
insert into Lugar_falleci values('Hospital, clinica o consultorio privado');
insert into Lugar_falleci values('Casa');
insert into Lugar_falleci values('Otro');

insert into cabe_form values ('1','Teniente Ortiz','4','Quito','Quitumbe','12/04/2018','123698','2','12/04/2018','147896325874125'); 

/*Tabla MORTALIDAD MATERNA*/

insert into Mor_Materna values ('Embarazo');
insert into Mor_Materna values ('Parto');
insert into Mor_Materna values ('Puerpio (Hasta 42 dias)');
insert into Mor_Materna values ('Entre 43 dias y 11 meses despues del parto o aborto');
insert into Mor_Materna values ('No estuvo embarazada durante los 11 meses previo la muerte');
insert into Mor_Materna values ('NULL');


/*Tabla MUERTES ACC VIO*/



insert into muerte_acc_vio values('Accidentes de transporte'); 
insert into muerte_acc_vio values('Otros accidentes'); 
insert into muerte_acc_vio values('Homicido'); 
insert into muerte_acc_vio values('Suicidio'); 
insert into muerte_acc_vio values('NULL'); 

/*Tabla LUGAR MUER*/

insert into lugar_muerte_violenta values ('Vivienda'); 
insert into lugar_muerte_violenta values ('Institucion residencial'); 
insert into lugar_muerte_violenta values ('Escuela u Oficina Publica'); 
insert into lugar_muerte_violenta values ('Areas deportivas'); 
insert into lugar_muerte_violenta values ('Calle o carretera (via publica)'); 
insert into lugar_muerte_violenta values ('Area comercial o de servicios'); 
insert into lugar_muerte_violenta values ('Areas Industriales'); 
insert into lugar_muerte_violenta values ('Area Agricola'); 
insert into lugar_muerte_violenta values ('Otro'); 
insert into lugar_muerte_violenta values ('Se ignora'); 


/*Tabla CERTIFICADOR*/

insert into certificador values ('Medico Tratante'); 
insert into certificador values ('Medico no Tratante'); 
insert into certificador values ('Medico Legista'); 
insert into certificador values ('Autoridad Civil o de Policia'); 
insert into certificador values ('Funcionario del Registro Civil');

/*Tabla PARENTESCO*/

insert into parentes values('Conyugue'); 
insert into parentes values('Hijo (a)'); 
insert into parentes values('Yerno o Nuera'); 
insert into parentes values('Nieto (a)'); 
insert into parentes values('Padres o Suegros'); 
insert into parentes values('Otros Parientes'); 
insert into parentes values('Otros NO parientes'); 

select * from cabe_form

/*CREACION DE LA TABLA AUDITORA y LOS TRIGGER POR CADA TABLA QUE VA A SER REGISTRADA POR EL USUARIO*/
use DefuncionGeneral

go 
create table Auditora(
id int identity not null, 
Persona varchar (50) not null,
Tabla varchar (50) not null,
Tipo varchar (40) not null,
Fecha date not null 
primary key (id)
)
go 

create trigger AuditoriaINSERT 
on cabe_form
for insert 
as 
	begin 
	insert Auditora select 'Area Local', 'CABE_FORM', 'INSERT', GETDATE()
	from inserted
	end;  


go 


create trigger AuditoriaINSERT2
on datos_fallecido
for insert 
as 
	begin 
	insert Auditora select 'Area Local', 'DATOS_FALLE', 'INSERT', GETDATE()
	from inserted
	end;  
go 

create trigger AuditoriaINSERT3
on certif_def
for insert 
as 
	begin 
	insert Auditora select 'Area Local', 'CERTIF_DEF', 'INSERT', GETDATE()
	from inserted
	end;  

go 

create trigger AuditoriaINSERT4
on datos_def
for insert 
as 
	begin 
	insert Auditora select 'Area Local', 'DATOS_DEF', 'INSERT', GETDATE()
	from inserted
	end;  

go 

create trigger AuditoriaINSERT5
on muerte_NO_cert
for insert 
as 
	begin 
	insert Auditora select 'Area Local', 'MUERTE_NO_CERT', 'INSERT', GETDATE()
	from inserted
	end;  


select * from Auditora


/*CON CERTIFICADO*/
select * from cabe_form, datos_fallecido, certif_def, datos_def 
where cabe_form.num_form = datos_fallecido.num_form and cabe_form.num_form = certif_def.num_form and
cabe_form.num_form = datos_def.num_form 

/*SIN CERTIFICADO*/
select * from cabe_form, datos_fallecido, muerte_NO_cert, datos_def 
where cabe_form.num_form = datos_fallecido.num_form and 
cabe_form.num_form = muerte_NO_cert.num_form and cabe_form.num_form = datos_def.num_form 
