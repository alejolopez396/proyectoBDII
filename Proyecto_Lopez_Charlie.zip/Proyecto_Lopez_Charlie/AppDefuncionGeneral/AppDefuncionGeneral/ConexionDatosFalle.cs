﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Forms; 


namespace AppDefuncionGeneral
{
    class ConexionDatosFalle
    {
        SqlConnection cn;
        SqlCommand cmd;
        SqlDataReader dr;


        //CONEXION A LA BASE DE DATOS... 
        public ConexionDatosFalle() {
            try
            {
                cn = new SqlConnection("Data Source=LAPTOP-NND7KTNQ\\SQLEXPRESS;Initial Catalog=DefuncionGeneral;Integrated Security=True");
                cn.Open();
                Console.WriteLine("LA BASE DE DATOS ESTA CONECTADA");
            }
            catch (Exception ex)
            {
                MessageBox.Show("LA BASE DE DATOS NO SE A CONECTADO: " + ex.ToString());
            }

        }

        //COMPLETAR LOS CAMPOS DEL COMBOBOX...
        //COMBO PROVINCIAS


        public void llenarComboProvincias(ComboBox cmbProv)
        {
            try
            {
                cmd = new SqlCommand("select provincia from provincias", cn);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cmbProv.Items.Add(dr["provincia"].ToString());
                }
                dr.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("NO SE LLENO EL COMBO" + ex.ToString());
            }
        }


        //COMBO ESTADO CIVIL
        public void llenarComboEstado(ComboBox cmbEstad)
        {
            try
            {
                cmd = new SqlCommand("select Estado_civil from estado_civil", cn);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cmbEstad.Items.Add(dr["Estado_civil"].ToString());
                }
                dr.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("NO SE LLENO EL COMBO" + ex.ToString());
            }
        }

        //COMBO SEXO 

        public void llenarComboSexo(ComboBox cmbSexo)
        {
            try
            {
                cmd = new SqlCommand("select Sexo from sexo", cn);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cmbSexo.Items.Add(dr["Sexo"].ToString());
                }
                dr.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("NO SE LLENO EL COMBO" + ex.ToString());
            }
        }

        //COMBO DE LUGAR OCURRENCIA


        public void llenarLugarOcu(ComboBox cmblug)
        {
            try
            {
                cmd = new SqlCommand("select Lugar from Lugar_falleci", cn);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cmblug.Items.Add(dr["Lugar"].ToString());
                }
                dr.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("NO SE LLENO EL COMBO" + ex.ToString());
            }
        }

        //COMBO INSTRUCCION 

        public void llenarInstruc(ComboBox cmbInstr)
        {
            try
            {
                cmd = new SqlCommand("select nivel from nivel_instruccion", cn);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cmbInstr.Items.Add(dr["nivel"].ToString());
                }
                dr.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("NO SE LLENO EL COMBO" + ex.ToString());
            }
        }


        //COMBO ETNIA


        public void llenarEtni(ComboBox cmbetni)
        {
            try
            {
                cmd = new SqlCommand("select Autoidentificacion from autoidentificacion", cn);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cmbetni.Items.Add(dr["Autoidentificacion"].ToString());
                }
                dr.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("NO SE LLENO EL COMBO" + ex.ToString());
            }
        }

        //INSERTAR DATOS DATOS FALLECIDO 


        public string insertarDatosFallecido(int id, int num_form, string nomApel, int nacionalidad, string paisOri, string Cedula, int sexo, string fechaNa, string FechaMuer, int horas, int dias,int mes,  int anios, int idprov, string canton, string parroquia, string local, string dir, int dpa, int loclDPA, int estado, int leerEsc, int nivel, int autoID, int lugarM)
        {
            string salida = "REGISTRO EXITOSO";
            try
            {
                cmd = new SqlCommand("insert into datos_fallecido (id_datos, num_form, nom_apel, nacionalidad, Pais_Origen, CI, id_sexo, fecha_nacimiento, fecha_fallecimiento, enHoras, enDias, enMeses, AniosCumplidos, id_provincia, Canton, parroquia, Localidad, Direccion_domici, dpa, localidad_DPA, id_estado, leer_escribir, id_nivel, id_autoidentificacion, id_lugar_muerte) values (" + id+", "+num_form+", '"+nomApel+"', "+nacionalidad+", '"+paisOri+"', '"+Cedula+"', "+sexo+", '"+fechaNa+"', '"+FechaMuer+"', "+horas+", "+dias+", "+mes+", "+anios+", "+idprov+", '"+canton+"', '"+parroquia+"', '"+local+"', '"+dir+"', "+dpa+", "+loclDPA+", "+estado+", "+leerEsc+", "+nivel+", "+autoID+", "+lugarM+" )", cn);
                cmd.ExecuteNonQuery();


            }
            catch (Exception ex)
            {
                salida = "NO SE INSERTARON LOS DATOS" + ex.ToString();
            }
            return salida;
        }

        //VERIFICAR SI EXISTE ESTE VALOR EN LA TABLA....

        public int validarDatosFalle(string ci)
        {
            int contador = 0;
            try
            {
                cmd = new SqlCommand("select * from datos_fallecido where CI like '" + ci + "'", cn);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    contador++;
                }
                dr.Close();



            }
            catch (Exception ex)
            {
                MessageBox.Show("No se puede realizar la consulta de verificacion: " + ex.ToString());
            }
            return contador;
        }







    }
}
