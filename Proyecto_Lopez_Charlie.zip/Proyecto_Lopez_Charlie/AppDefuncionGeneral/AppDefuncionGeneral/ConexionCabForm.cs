﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Data; 
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Forms; 


namespace AppDefuncionGeneral
{
    class ConexionCabForm
    {
        SqlConnection cn;
        SqlCommand cmd;
        SqlDataReader dr;


        //CONEXION A LA BASE DE DATOS.....
        public ConexionCabForm() {

            try {
                cn = new SqlConnection("Data Source=LAPTOP-NND7KTNQ\\SQLEXPRESS;Initial Catalog=DefuncionGeneral;Integrated Security=True");
                cn.Open();
                MessageBox.Show("LA BASE DE DATOS ESTA CONECTADA");
            }
            catch (Exception ex) {
                MessageBox.Show("LA BASE DE DATOS NO SE A CONECTADO: "+ ex.ToString()); 
            }
            
        }


        //LLENAR COMBO...
        public void llenarComboProvincias(ComboBox cmbProv) {
            try {
                cmd = new SqlCommand("select provincia from provincias",cn);
                dr = cmd.ExecuteReader();
                while (dr.Read()) {
                    cmbProv.Items.Add(dr["provincia"].ToString()); 
                }
                dr.Close(); 

            }
            catch (Exception ex) {
                MessageBox.Show("NO SE LLENO EL COMBO"+ ex.ToString());
            }
        }


        //INSERTAR EN LA TABLA CABE_FORM.. 

        public string insertarcabeForm(int id, string ofRegistro, int idPro,string canton, string parroquia, string fechaIns, int dpa, int numOf, string fechaDPA, int acta) {
            string salida = "REGISTRO EXITOSO"; 
            try {
                cmd = new SqlCommand("insert into cabe_form (num_form, of_regis, id_provincia, canton, parroquia, fecha_ins, dpa, num_of_reg, fecha_dpa, acta_inscripcion) values ("+id+", '"+ofRegistro+"', "+idPro+",'"+canton+"','"+parroquia+"','"+fechaIns+"', "+dpa+", "+numOf+",'"+fechaDPA+"',"+acta+" )", cn);
                cmd.ExecuteNonQuery();


            }
            catch (Exception ex)  {
                salida = "NO SE INSERTARON LOS DATOS" + ex.ToString();
            }
            return salida; 
        }

        //VERIFICAR SI EXISTE ESTE VALOR EN LA TABLA....
        public int validarCabe(int id)
        {
            int contador = 0; 
            try
            {
                cmd = new SqlCommand("select * from cabe_form where num_form = "+id+ "", cn);
                dr = cmd.ExecuteReader();
                while (dr.Read()) {
                    contador++; 
                }
                dr.Close(); 



            }
            catch (Exception ex)
            {
                MessageBox.Show("No se puede realizar la consulta de verificacion: "+ ex.ToString()); 
            }
            return contador;
        }





    }
}
