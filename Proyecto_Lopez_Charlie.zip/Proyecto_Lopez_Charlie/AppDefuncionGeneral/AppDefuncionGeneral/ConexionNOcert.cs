﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Forms; 



namespace AppDefuncionGeneral
{
    class ConexionNOcert
    {
        SqlConnection cn;
        SqlCommand cmd;
        SqlDataReader dr;




        public ConexionNOcert() {
            try
            {
                cn.Open();
                cn = new SqlConnection("Data Source=LAPTOP-NND7KTNQ\\SQLEXPRESS;Initial Catalog=DefuncionGeneral;Integrated Security=True");
                Console.WriteLine("LA BASE DE DATOS ESTA CONECTADA");
            }
            catch (Exception ex)
            {
                MessageBox.Show("LA BASE DE DATOS NO SE A CONECTADO: " + ex.ToString());
            }

        }

        //INSERCION DE DATOS NO CERT 

        public string insertarDatosFallecido(int num, string CausaPr, string Sintomas, string NomT1, string NomT2, string dirT1, string dirT2, string telT1, string telT2)
        {
            string salida = "REGISTRO EXITOSO :D";
            try
            {
                cmd = new SqlCommand("insert into muerte_NO_cert (num_form, CausaProb, Sintomas, Nom_apel_Testigo1, Nom_apel_Testigo2, Dir_tes1, Dir_tes2, telf_tes1, telf_tes2) values ("+num+ ", '"+CausaPr+"', '"+Sintomas+"', '" + NomT1+"', '"+NomT2+"',  '"+dirT1+"', '"+dirT2+"', '"+telT1+"', '"+telT2+"')", cn);
                cmd.ExecuteNonQuery();


            }
            catch (Exception ex)
            {
                salida = "NO SE INSERTARON LOS DATOS D:" + ex.ToString();
            }
            return salida;
        }






    }
}
