﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppDefuncionGeneral
{
    public partial class Form1 : Form
    {

        ConexionCabForm Cabe = new ConexionCabForm(); 
       


        public Form1()
        {
            InitializeComponent();
        }

        private void btnWardCAB_Click(object sender, EventArgs e)
        {
            //VAMOS A INSERTAR LOS DATOS.. 

            int valorCombo = cmbProv.SelectedIndex + 1;  

            if (Cabe.validarCabe(Convert.ToInt32(txtidCabe.Text)) == 0) {
                MessageBox.Show(Cabe.insertarcabeForm(Convert.ToInt32(txtidCabe.Text), 
                  txtOfReg.Text, valorCombo,txtCant.Text,txtParro.Text, dtpIns.Text, 
                  Convert.ToInt32(txtInec.Text), Convert.ToInt32(txtNumOf.Text),dtpCrit.Text, 
                  Convert.ToInt32(txtAct.Text)));

                txtOfReg.Text = "";
                txtCant.Text = "";
                txtParro.Text = "";
                txtInec.Text = "";
                txtNumOf.Text = "";
                txtidCabe.Text = "";
                txtAct.Text = "";
                cmbProv.SelectedIndex = -1;


                Form ParteA = new Form2();
                this.Hide();
                ParteA.ShowDialog(); 
                this.Close();


            }
            else {
                MessageBox.Show("ESTE REGISTRO YA EXISTE");
                txtidCabe.Text = "";

            }



        }

        private void Form1_Load(object sender, EventArgs e)
        {

            //APENAS INICIA SE CARGA EL COMBO MANDANDO COMO PARAMETRO... AL COMBO QUE QUEREMOS LLENAR
            //EL METODO LLENAR COMBO ESTA EN LA CONEXION A CABEFORM
            Cabe.llenarComboProvincias(cmbProv);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form vuelve1 = new Form6();
            this.Hide();
            vuelve1.ShowDialog();
            this.Close();
        }
    }
}
