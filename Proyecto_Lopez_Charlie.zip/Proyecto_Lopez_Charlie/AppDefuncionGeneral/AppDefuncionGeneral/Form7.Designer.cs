﻿namespace AppDefuncionGeneral
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form7));
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.cabeformBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.defuncionGeneralDataSet = new AppDefuncionGeneral.DefuncionGeneralDataSet();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.numformDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ofregisDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idprovinciaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cantonDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.parroquiaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechainsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dpaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numofregDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechadpaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.actainscripcionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.fillBy1ToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillBy1ToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.cabe_formTableAdapter = new AppDefuncionGeneral.DefuncionGeneralDataSetTableAdapters.cabe_formTableAdapter();
            this.muerte_NO_certTableAdapter = new AppDefuncionGeneral.DefuncionGeneralDataSetTableAdapters.muerte_NO_certTableAdapter();
            this.idNOcertDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numformDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.causaProbDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sintomasDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomapelTestigo1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomapelTestigo2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dirtes1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dirtes2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telftes1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telftes2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fKmuerteNOnumf3B75D760BindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.cabeformBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.defuncionGeneralDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.fillBy1ToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fKmuerteNOnumf3B75D760BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 52);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(310, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "FALLECIDOS / AS REGISTRADOS EN LA BASE";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(725, 501);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(157, 28);
            this.button1.TabIndex = 2;
            this.button1.Text = "REGRESAR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // cabeformBindingSource
            // 
            this.cabeformBindingSource.DataMember = "cabe_form";
            this.cabeformBindingSource.DataSource = this.defuncionGeneralDataSet;
            // 
            // defuncionGeneralDataSet
            // 
            this.defuncionGeneralDataSet.DataSetName = "DefuncionGeneralDataSet";
            this.defuncionGeneralDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.GrayText;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.numformDataGridViewTextBoxColumn,
            this.ofregisDataGridViewTextBoxColumn,
            this.idprovinciaDataGridViewTextBoxColumn,
            this.cantonDataGridViewTextBoxColumn,
            this.parroquiaDataGridViewTextBoxColumn,
            this.fechainsDataGridViewTextBoxColumn,
            this.dpaDataGridViewTextBoxColumn,
            this.numofregDataGridViewTextBoxColumn,
            this.fechadpaDataGridViewTextBoxColumn,
            this.actainscripcionDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.cabeformBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(21, 102);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(861, 170);
            this.dataGridView1.TabIndex = 3;
            // 
            // numformDataGridViewTextBoxColumn
            // 
            this.numformDataGridViewTextBoxColumn.DataPropertyName = "num_form";
            this.numformDataGridViewTextBoxColumn.HeaderText = "num_form";
            this.numformDataGridViewTextBoxColumn.Name = "numformDataGridViewTextBoxColumn";
            // 
            // ofregisDataGridViewTextBoxColumn
            // 
            this.ofregisDataGridViewTextBoxColumn.DataPropertyName = "of_regis";
            this.ofregisDataGridViewTextBoxColumn.HeaderText = "of_regis";
            this.ofregisDataGridViewTextBoxColumn.Name = "ofregisDataGridViewTextBoxColumn";
            // 
            // idprovinciaDataGridViewTextBoxColumn
            // 
            this.idprovinciaDataGridViewTextBoxColumn.DataPropertyName = "id_provincia";
            this.idprovinciaDataGridViewTextBoxColumn.HeaderText = "id_provincia";
            this.idprovinciaDataGridViewTextBoxColumn.Name = "idprovinciaDataGridViewTextBoxColumn";
            // 
            // cantonDataGridViewTextBoxColumn
            // 
            this.cantonDataGridViewTextBoxColumn.DataPropertyName = "canton";
            this.cantonDataGridViewTextBoxColumn.HeaderText = "canton";
            this.cantonDataGridViewTextBoxColumn.Name = "cantonDataGridViewTextBoxColumn";
            // 
            // parroquiaDataGridViewTextBoxColumn
            // 
            this.parroquiaDataGridViewTextBoxColumn.DataPropertyName = "parroquia";
            this.parroquiaDataGridViewTextBoxColumn.HeaderText = "parroquia";
            this.parroquiaDataGridViewTextBoxColumn.Name = "parroquiaDataGridViewTextBoxColumn";
            // 
            // fechainsDataGridViewTextBoxColumn
            // 
            this.fechainsDataGridViewTextBoxColumn.DataPropertyName = "fecha_ins";
            this.fechainsDataGridViewTextBoxColumn.HeaderText = "fecha_ins";
            this.fechainsDataGridViewTextBoxColumn.Name = "fechainsDataGridViewTextBoxColumn";
            // 
            // dpaDataGridViewTextBoxColumn
            // 
            this.dpaDataGridViewTextBoxColumn.DataPropertyName = "dpa";
            this.dpaDataGridViewTextBoxColumn.HeaderText = "dpa";
            this.dpaDataGridViewTextBoxColumn.Name = "dpaDataGridViewTextBoxColumn";
            // 
            // numofregDataGridViewTextBoxColumn
            // 
            this.numofregDataGridViewTextBoxColumn.DataPropertyName = "num_of_reg";
            this.numofregDataGridViewTextBoxColumn.HeaderText = "num_of_reg";
            this.numofregDataGridViewTextBoxColumn.Name = "numofregDataGridViewTextBoxColumn";
            // 
            // fechadpaDataGridViewTextBoxColumn
            // 
            this.fechadpaDataGridViewTextBoxColumn.DataPropertyName = "fecha_dpa";
            this.fechadpaDataGridViewTextBoxColumn.HeaderText = "fecha_dpa";
            this.fechadpaDataGridViewTextBoxColumn.Name = "fechadpaDataGridViewTextBoxColumn";
            // 
            // actainscripcionDataGridViewTextBoxColumn
            // 
            this.actainscripcionDataGridViewTextBoxColumn.DataPropertyName = "acta_inscripcion";
            this.actainscripcionDataGridViewTextBoxColumn.HeaderText = "acta_inscripcion";
            this.actainscripcionDataGridViewTextBoxColumn.Name = "actainscripcionDataGridViewTextBoxColumn";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 82);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(165, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Fallecidos CERTIFICADO";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 286);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(191, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Fallecidos SIN CERTIFICADO";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idNOcertDataGridViewTextBoxColumn,
            this.numformDataGridViewTextBoxColumn1,
            this.causaProbDataGridViewTextBoxColumn,
            this.sintomasDataGridViewTextBoxColumn,
            this.nomapelTestigo1DataGridViewTextBoxColumn,
            this.nomapelTestigo2DataGridViewTextBoxColumn,
            this.dirtes1DataGridViewTextBoxColumn,
            this.dirtes2DataGridViewTextBoxColumn,
            this.telftes1DataGridViewTextBoxColumn,
            this.telftes2DataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.fKmuerteNOnumf3B75D760BindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(25, 305);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(857, 185);
            this.dataGridView2.TabIndex = 6;
            // 
            // fillBy1ToolStrip
            // 
            this.fillBy1ToolStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.fillBy1ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillBy1ToolStripButton});
            this.fillBy1ToolStrip.Location = new System.Drawing.Point(0, 0);
            this.fillBy1ToolStrip.Name = "fillBy1ToolStrip";
            this.fillBy1ToolStrip.Size = new System.Drawing.Size(909, 27);
            this.fillBy1ToolStrip.TabIndex = 7;
            this.fillBy1ToolStrip.Text = "fillBy1ToolStrip";
            // 
            // fillBy1ToolStripButton
            // 
            this.fillBy1ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillBy1ToolStripButton.Name = "fillBy1ToolStripButton";
            this.fillBy1ToolStripButton.Size = new System.Drawing.Size(56, 24);
            this.fillBy1ToolStripButton.Text = "FillBy1";
            this.fillBy1ToolStripButton.Click += new System.EventHandler(this.fillBy1ToolStripButton_Click);
            // 
            // cabe_formTableAdapter
            // 
            this.cabe_formTableAdapter.ClearBeforeFill = true;
            // 
            // muerte_NO_certTableAdapter
            // 
            this.muerte_NO_certTableAdapter.ClearBeforeFill = true;
            // 
            // idNOcertDataGridViewTextBoxColumn
            // 
            this.idNOcertDataGridViewTextBoxColumn.DataPropertyName = "id_NOcert";
            this.idNOcertDataGridViewTextBoxColumn.HeaderText = "id_NOcert";
            this.idNOcertDataGridViewTextBoxColumn.Name = "idNOcertDataGridViewTextBoxColumn";
            this.idNOcertDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // numformDataGridViewTextBoxColumn1
            // 
            this.numformDataGridViewTextBoxColumn1.DataPropertyName = "num_form";
            this.numformDataGridViewTextBoxColumn1.HeaderText = "num_form";
            this.numformDataGridViewTextBoxColumn1.Name = "numformDataGridViewTextBoxColumn1";
            // 
            // causaProbDataGridViewTextBoxColumn
            // 
            this.causaProbDataGridViewTextBoxColumn.DataPropertyName = "CausaProb";
            this.causaProbDataGridViewTextBoxColumn.HeaderText = "CausaProb";
            this.causaProbDataGridViewTextBoxColumn.Name = "causaProbDataGridViewTextBoxColumn";
            // 
            // sintomasDataGridViewTextBoxColumn
            // 
            this.sintomasDataGridViewTextBoxColumn.DataPropertyName = "Sintomas";
            this.sintomasDataGridViewTextBoxColumn.HeaderText = "Sintomas";
            this.sintomasDataGridViewTextBoxColumn.Name = "sintomasDataGridViewTextBoxColumn";
            // 
            // nomapelTestigo1DataGridViewTextBoxColumn
            // 
            this.nomapelTestigo1DataGridViewTextBoxColumn.DataPropertyName = "Nom_apel_Testigo1";
            this.nomapelTestigo1DataGridViewTextBoxColumn.HeaderText = "Nom_apel_Testigo1";
            this.nomapelTestigo1DataGridViewTextBoxColumn.Name = "nomapelTestigo1DataGridViewTextBoxColumn";
            // 
            // nomapelTestigo2DataGridViewTextBoxColumn
            // 
            this.nomapelTestigo2DataGridViewTextBoxColumn.DataPropertyName = "Nom_apel_Testigo2";
            this.nomapelTestigo2DataGridViewTextBoxColumn.HeaderText = "Nom_apel_Testigo2";
            this.nomapelTestigo2DataGridViewTextBoxColumn.Name = "nomapelTestigo2DataGridViewTextBoxColumn";
            // 
            // dirtes1DataGridViewTextBoxColumn
            // 
            this.dirtes1DataGridViewTextBoxColumn.DataPropertyName = "Dir_tes1";
            this.dirtes1DataGridViewTextBoxColumn.HeaderText = "Dir_tes1";
            this.dirtes1DataGridViewTextBoxColumn.Name = "dirtes1DataGridViewTextBoxColumn";
            // 
            // dirtes2DataGridViewTextBoxColumn
            // 
            this.dirtes2DataGridViewTextBoxColumn.DataPropertyName = "Dir_tes2";
            this.dirtes2DataGridViewTextBoxColumn.HeaderText = "Dir_tes2";
            this.dirtes2DataGridViewTextBoxColumn.Name = "dirtes2DataGridViewTextBoxColumn";
            // 
            // telftes1DataGridViewTextBoxColumn
            // 
            this.telftes1DataGridViewTextBoxColumn.DataPropertyName = "telf_tes1";
            this.telftes1DataGridViewTextBoxColumn.HeaderText = "telf_tes1";
            this.telftes1DataGridViewTextBoxColumn.Name = "telftes1DataGridViewTextBoxColumn";
            // 
            // telftes2DataGridViewTextBoxColumn
            // 
            this.telftes2DataGridViewTextBoxColumn.DataPropertyName = "telf_tes2";
            this.telftes2DataGridViewTextBoxColumn.HeaderText = "telf_tes2";
            this.telftes2DataGridViewTextBoxColumn.Name = "telftes2DataGridViewTextBoxColumn";
            // 
            // fKmuerteNOnumf3B75D760BindingSource
            // 
            this.fKmuerteNOnumf3B75D760BindingSource.DataMember = "FK__muerte_NO__num_f__3B75D760";
            this.fKmuerteNOnumf3B75D760BindingSource.DataSource = this.cabeformBindingSource;
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::AppDefuncionGeneral.Properties.Resources.background_tumblr_blue_pastel_5;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(909, 533);
            this.Controls.Add(this.fillBy1ToolStrip);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form7";
            this.Text = "Vista de Datos";
            this.Load += new System.EventHandler(this.Form7_Load);
            ((System.ComponentModel.ISupportInitialize)(this.cabeformBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.defuncionGeneralDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.fillBy1ToolStrip.ResumeLayout(false);
            this.fillBy1ToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fKmuerteNOnumf3B75D760BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private DefuncionGeneralDataSet defuncionGeneralDataSet;
        private System.Windows.Forms.BindingSource cabeformBindingSource;
        private DefuncionGeneralDataSetTableAdapters.cabe_formTableAdapter cabe_formTableAdapter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.BindingSource fKmuerteNOnumf3B75D760BindingSource;
        private DefuncionGeneralDataSetTableAdapters.muerte_NO_certTableAdapter muerte_NO_certTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn numformDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ofregisDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idprovinciaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cantonDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn parroquiaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechainsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dpaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numofregDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechadpaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn actainscripcionDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn idNOcertDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numformDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn causaProbDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sintomasDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomapelTestigo1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomapelTestigo2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dirtes1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dirtes2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telftes1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telftes2DataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStrip fillBy1ToolStrip;
        private System.Windows.Forms.ToolStripButton fillBy1ToolStripButton;
    }
}