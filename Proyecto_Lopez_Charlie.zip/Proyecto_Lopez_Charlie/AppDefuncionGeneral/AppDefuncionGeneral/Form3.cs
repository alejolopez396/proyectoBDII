﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppDefuncionGeneral
{
    public partial class Form3 : Form
    {
        ConexionCertif conexionCert = new ConexionCertif(); 

        public Form3()
        {
            InitializeComponent();
        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            conexionCert.llenarComboMortalidadMaterna(cmbMorMa);
            conexionCert.llenarComboMuerViol(cmbViolent);
            conexionCert.llenarComboLugar(cmbLugar);
            cmbAuto.Items.Add("NO");
            cmbAuto.Items.Add("SI");
            panel1.Enabled = false;
            panel2.Enabled = false;
            panel3.Enabled = false; 
            cmbValidacion.Items.Add("NO");
            cmbValidacion.Items.Add("SI");
            btnWard3.Enabled = false; 
        }

        private void cmbGenero_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void btnWard3_Click(object sender, EventArgs e)
        {
            int numMorMa = cmbMorMa.SelectedIndex + 1;
            int numVIo = cmbViolent.SelectedIndex + 1;
            int numAut = cmbAuto.SelectedIndex;
            int numLug = cmbLugar.SelectedIndex + 1;

            if (cmbValidacion.SelectedIndex == 1)
            {
                

                if (conexionCert.validarDatosCERT(Convert.ToInt32(txtInec.Text)) == 0)
                {
                    MessageBox.Show(conexionCert.insertarCertificado(Convert.ToInt32(txtidCAB.Text), txtCausaA.Text, txtCausaB.Text, txtCausaC.Text, txtCausaD.Text, Convert.ToInt32(txtTiempoA.Text), Convert.ToInt32(txtTiempoB.Text), Convert.ToInt32(txtTiempoC.Text), Convert.ToInt32(txtTiempoD.Text), Convert.ToInt32(txtCodA.Text), Convert.ToInt32(txtCodB.Text), Convert.ToInt32(txtCodC.Text), Convert.ToInt32(txtCodD.Text), txtCausaEs.Text, Convert.ToInt32(txtTiempoEs.Text), Convert.ToInt32(txtInec.Text), numMorMa, numVIo, numLug, txtDescri.Text, numAut));
                    txtCausaA.Text = "";
                    txtCausaB.Text = "";
                    txtCausaC.Text = "";
                    txtCausaD.Text = "";
                    txtCausaEs.Text = "";
                    txtCodA.Text = "";
                    txtCodB.Text = "";
                    txtCodC.Text = "";
                    txtCodD.Text = "";
                    txtDescri.Text = "";
                    txtidCAB.Text = "";
                    txtInec.Text = "";
                    txtTiempoA.Text = "";
                    txtTiempoB.Text = "";
                    txtTiempoC.Text = "";
                    txtTiempoD.Text = "";
                    txtTiempoEs.Text = "";
                    cmbAuto.SelectedIndex = -1;
                    cmbLugar.SelectedIndex = -1;
                    cmbMorMa.SelectedIndex = -1;
                    cmbViolent.SelectedIndex = -1;

                    //AQUI DEBERIA LLAMAR A LA VENTA FORM 5
                    Form ParteC = new Form5();
                    this.Hide();
                    ParteC.ShowDialog();
                    this.Close();

                }
                else
                {
                    MessageBox.Show("ESTE REGISTRO YA EXISTE");

 
                }



            }
            else {

                Console.WriteLine("NUNCA LLEGA");

            }
            



        }

        private void cmbValidacion_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbValidacion.SelectedIndex == 1 ) {
                panel1.Enabled = true;
                panel2.Enabled = true;
                panel3.Enabled = true;
                btnWard3.Enabled = true;
                btnWard3.Text = "GUARDAR Y SEGUIR";
            }

            if (cmbValidacion.SelectedIndex == 0) {

                panel1.Enabled = false;
                panel2.Enabled =false;
                panel3.Enabled = false;
                

                MessageBox.Show("Avance a la siguiente ventana..."); 

                //LLAMO A LA VENTANA 4
                Form ParteC = new Form4();
                this.Hide();
                ParteC.ShowDialog();
                this.Close();
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form vuelve1 = new Form2();
            this.Hide();
            vuelve1.ShowDialog();
            this.Close();
        }
    }
}
