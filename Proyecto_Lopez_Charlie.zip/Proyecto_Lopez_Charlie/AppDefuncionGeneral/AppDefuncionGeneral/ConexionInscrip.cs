﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AppDefuncionGeneral
{
    class ConexionInscrip
    {
        SqlConnection cn;
        SqlCommand cmd;
        SqlDataReader dr;

        public ConexionInscrip()
        {
            try
            {
                cn = new SqlConnection("Data Source=LAPTOP-NND7KTNQ\\SQLEXPRESS;Initial Catalog=DefuncionGeneral;Integrated Security=True");
                cn.Open();
                Console.WriteLine("LA BASE DE DATOS ESTA CONECTADA");
            }
            catch (Exception ex)
            {
                MessageBox.Show("LA BASE DE DATOS NO SE A CONECTADO: " + ex.ToString());
            }

            

        }

        //LLENAR COMBO CERTIFICADOR....

        public void llenarComboCert(ComboBox cmb)
        {
            try
            {
                cmd = new SqlCommand("select tipo from certificador", cn);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cmb.Items.Add(dr["tipo"].ToString());
                }
                dr.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("NO SE LLENO EL COMBO" + ex.ToString());
            }
        }


        //LLENAR COMBO PARENTESCO

        public void llenarParent(ComboBox cmb)
        {
            try
            {
                cmd = new SqlCommand("select parentesco from parentes", cn);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cmb.Items.Add(dr["parentesco"].ToString());
                }
                dr.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("NO SE LLENO EL COMBO" + ex.ToString());
            }
        }

        //INSERTAR DATOS...

        
        public string insertarDatosInse(int num, int id_cer, string nomapelCert, string ci, string dircert, string telfcert, string nomapelSOL, int edadsol, int parent, string obs)
        {
            string salida = "REGISTRO EXITOSO";
            try
            {
                cmd = new SqlCommand("insert into datos_def (num_form, id_certificador, Nom_apel_certificador,CI_Certificador , Direccion_Certificador, telefono, Nom_apel_solicita, edad, id_paren, Observaciones) values ("+num+", "+id_cer+", '"+nomapelCert+"', '"+ci+"', '"+dircert+"', '"+telfcert+"', '"+nomapelSOL+"', '"+edadsol+"', "+parent+", '"+obs+"')", cn);
                cmd.ExecuteNonQuery();


            }
            catch (Exception ex)
            {
                salida = "NO SE INSERTARON LOS DATOS" + ex.ToString();
            }
            return salida;
        }


    }
}
