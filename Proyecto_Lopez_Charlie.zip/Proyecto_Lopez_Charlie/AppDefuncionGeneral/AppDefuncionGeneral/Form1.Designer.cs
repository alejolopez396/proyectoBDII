﻿namespace AppDefuncionGeneral
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtidCabe = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtOfReg = new System.Windows.Forms.TextBox();
            this.cmbProv = new System.Windows.Forms.ComboBox();
            this.txtCant = new System.Windows.Forms.TextBox();
            this.txtParro = new System.Windows.Forms.TextBox();
            this.txtAct = new System.Windows.Forms.TextBox();
            this.dtpIns = new System.Windows.Forms.DateTimePicker();
            this.dtpCrit = new System.Windows.Forms.DateTimePicker();
            this.txtInec = new System.Windows.Forms.TextBox();
            this.txtNumOf = new System.Windows.Forms.TextBox();
            this.btnWardCAB = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 16);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(276, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "FORMULARIO DE DEFUNCIÓN GENERAL";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(843, 15);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(24, 17);
            this.label9.TabIndex = 2;
            this.label9.Text = "N°";
            // 
            // txtidCabe
            // 
            this.txtidCabe.Location = new System.Drawing.Point(876, 11);
            this.txtidCabe.Margin = new System.Windows.Forms.Padding(4);
            this.txtidCabe.Name = "txtidCabe";
            this.txtidCabe.Size = new System.Drawing.Size(109, 22);
            this.txtidCabe.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 5);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(856, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "La información de este recuadro deberá ser llenado por funcionarios de las oficin" +
    "as del Registro Civil, en el momento de la inscripcion.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 47);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(244, 17);
            this.label3.TabIndex = 1;
            this.label3.Text = "1) OFICINA DE REGISTRO CIVIL DE: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 79);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 17);
            this.label4.TabIndex = 2;
            this.label4.Text = "2) PROVINCIA: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 116);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 17);
            this.label5.TabIndex = 3;
            this.label5.Text = "CANTÓN: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 164);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(225, 17);
            this.label6.TabIndex = 4;
            this.label6.Text = "PARROQUIA URBANA O RURAL: ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(563, 111);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(191, 17);
            this.label7.TabIndex = 5;
            this.label7.Text = "3) FECHA DE INSCRIPCION: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(572, 143);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(182, 17);
            this.label8.TabIndex = 6;
            this.label8.Text = "4) ACTA DE INSCRIPCIÓN: ";
            // 
            // txtOfReg
            // 
            this.txtOfReg.Location = new System.Drawing.Point(268, 47);
            this.txtOfReg.Margin = new System.Windows.Forms.Padding(4);
            this.txtOfReg.MaxLength = 40;
            this.txtOfReg.Name = "txtOfReg";
            this.txtOfReg.Size = new System.Drawing.Size(289, 22);
            this.txtOfReg.TabIndex = 7;
            // 
            // cmbProv
            // 
            this.cmbProv.FormattingEnabled = true;
            this.cmbProv.Location = new System.Drawing.Point(125, 79);
            this.cmbProv.Margin = new System.Windows.Forms.Padding(4);
            this.cmbProv.Name = "cmbProv";
            this.cmbProv.Size = new System.Drawing.Size(432, 24);
            this.cmbProv.TabIndex = 8;
            // 
            // txtCant
            // 
            this.txtCant.Location = new System.Drawing.Point(109, 111);
            this.txtCant.Margin = new System.Windows.Forms.Padding(4);
            this.txtCant.MaxLength = 50;
            this.txtCant.Name = "txtCant";
            this.txtCant.Size = new System.Drawing.Size(448, 22);
            this.txtCant.TabIndex = 9;
            // 
            // txtParro
            // 
            this.txtParro.Location = new System.Drawing.Point(266, 159);
            this.txtParro.Margin = new System.Windows.Forms.Padding(4);
            this.txtParro.MaxLength = 50;
            this.txtParro.Name = "txtParro";
            this.txtParro.Size = new System.Drawing.Size(291, 22);
            this.txtParro.TabIndex = 10;
            // 
            // txtAct
            // 
            this.txtAct.Location = new System.Drawing.Point(771, 138);
            this.txtAct.Margin = new System.Windows.Forms.Padding(4);
            this.txtAct.MaxLength = 9;
            this.txtAct.Name = "txtAct";
            this.txtAct.Size = new System.Drawing.Size(197, 22);
            this.txtAct.TabIndex = 11;
            // 
            // dtpIns
            // 
            this.dtpIns.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpIns.Location = new System.Drawing.Point(771, 106);
            this.dtpIns.Margin = new System.Windows.Forms.Padding(4);
            this.dtpIns.Name = "dtpIns";
            this.dtpIns.Size = new System.Drawing.Size(120, 22);
            this.dtpIns.TabIndex = 12;
            // 
            // dtpCrit
            // 
            this.dtpCrit.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpCrit.Location = new System.Drawing.Point(848, 47);
            this.dtpCrit.Margin = new System.Windows.Forms.Padding(4);
            this.dtpCrit.Name = "dtpCrit";
            this.dtpCrit.Size = new System.Drawing.Size(120, 22);
            this.dtpCrit.TabIndex = 13;
            // 
            // txtInec
            // 
            this.txtInec.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtInec.Location = new System.Drawing.Point(575, 47);
            this.txtInec.Margin = new System.Windows.Forms.Padding(4);
            this.txtInec.MaxLength = 6;
            this.txtInec.Name = "txtInec";
            this.txtInec.Size = new System.Drawing.Size(185, 22);
            this.txtInec.TabIndex = 14;
            // 
            // txtNumOf
            // 
            this.txtNumOf.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtNumOf.Location = new System.Drawing.Point(771, 47);
            this.txtNumOf.Margin = new System.Windows.Forms.Padding(4);
            this.txtNumOf.MaxLength = 3;
            this.txtNumOf.Name = "txtNumOf";
            this.txtNumOf.Size = new System.Drawing.Size(59, 22);
            this.txtNumOf.TabIndex = 15;
            // 
            // btnWardCAB
            // 
            this.btnWardCAB.Location = new System.Drawing.Point(747, 192);
            this.btnWardCAB.Margin = new System.Windows.Forms.Padding(4);
            this.btnWardCAB.Name = "btnWardCAB";
            this.btnWardCAB.Size = new System.Drawing.Size(223, 28);
            this.btnWardCAB.TabIndex = 16;
            this.btnWardCAB.Text = "GUARDAR Y SEGUIR";
            this.btnWardCAB.UseVisualStyleBackColor = true;
            this.btnWardCAB.Click += new System.EventHandler(this.btnWardCAB_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(631, 26);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 17);
            this.label10.TabIndex = 17;
            this.label10.Text = "USO INEC";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(768, 26);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(62, 17);
            this.label11.TabIndex = 18;
            this.label11.Text = "OFIC. Nº";
            // 
            // panel1
            // 
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.btnWardCAB);
            this.panel1.Controls.Add(this.txtNumOf);
            this.panel1.Controls.Add(this.txtInec);
            this.panel1.Controls.Add(this.dtpCrit);
            this.panel1.Controls.Add(this.dtpIns);
            this.panel1.Controls.Add(this.txtAct);
            this.panel1.Controls.Add(this.txtParro);
            this.panel1.Controls.Add(this.txtCant);
            this.panel1.Controls.Add(this.cmbProv);
            this.panel1.Controls.Add(this.txtOfReg);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(16, 55);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(996, 224);
            this.panel1.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(498, 193);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(221, 27);
            this.button1.TabIndex = 19;
            this.button1.Text = "REGRESAR AL INICIO";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::AppDefuncionGeneral.Properties.Resources.Creative_Tumblr_Backgrounds_2;
            this.ClientSize = new System.Drawing.Size(1020, 294);
            this.Controls.Add(this.txtidCabe);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Registro";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtidCabe;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtOfReg;
        private System.Windows.Forms.ComboBox cmbProv;
        private System.Windows.Forms.TextBox txtCant;
        private System.Windows.Forms.TextBox txtParro;
        private System.Windows.Forms.TextBox txtAct;
        private System.Windows.Forms.DateTimePicker dtpIns;
        private System.Windows.Forms.DateTimePicker dtpCrit;
        private System.Windows.Forms.TextBox txtInec;
        private System.Windows.Forms.TextBox txtNumOf;
        private System.Windows.Forms.Button btnWardCAB;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
    }
}

