﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppDefuncionGeneral
{
    public partial class Form7 : Form
    {


        public Form7()
        {
            InitializeComponent();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'defuncionGeneralDataSet.muerte_NO_cert' Puede moverla o quitarla según sea necesario.
            this.muerte_NO_certTableAdapter.Fill(this.defuncionGeneralDataSet.muerte_NO_cert);
            // TODO: esta línea de código carga datos en la tabla 'defuncionGeneralDataSet.cabe_form' Puede moverla o quitarla según sea necesario.
            this.cabe_formTableAdapter.Fill(this.defuncionGeneralDataSet.cabe_form);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form vuelve1 = new Form6();
            this.Hide();
            vuelve1.ShowDialog();
            this.Close(); 

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.cabe_formTableAdapter.FillBy(this.defuncionGeneralDataSet.cabe_form);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillByToolStripButton1_Click(object sender, EventArgs e)
        {
            try
            {
                this.muerte_NO_certTableAdapter.FillBy(this.defuncionGeneralDataSet.muerte_NO_cert);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillBy1ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.muerte_NO_certTableAdapter.FillBy1(this.defuncionGeneralDataSet.muerte_NO_cert);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
