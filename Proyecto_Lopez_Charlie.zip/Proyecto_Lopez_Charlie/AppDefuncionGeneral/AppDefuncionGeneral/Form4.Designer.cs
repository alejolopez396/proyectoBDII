﻿namespace AppDefuncionGeneral
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtTelT2 = new System.Windows.Forms.TextBox();
            this.txtDiT2 = new System.Windows.Forms.TextBox();
            this.txtTelT1 = new System.Windows.Forms.TextBox();
            this.txtDiT1 = new System.Windows.Forms.TextBox();
            this.txtSintomas = new System.Windows.Forms.TextBox();
            this.txtCausaProb = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtNoAeT2 = new System.Windows.Forms.TextBox();
            this.txtNoApT1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtIdCab = new System.Windows.Forms.TextBox();
            this.btnWard4 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnRegresaala3 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 22);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(321, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "C) PARA MUERTES SIN CERTIFICACION MÉDICA";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 11);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(271, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "21) CAUSA PROBABLE DE LA MUERTE: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(209, 44);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Sintomas: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 11);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "N° Cabecera";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.txtTelT2);
            this.panel1.Controls.Add(this.txtDiT2);
            this.panel1.Controls.Add(this.txtTelT1);
            this.panel1.Controls.Add(this.txtDiT1);
            this.panel1.Controls.Add(this.txtSintomas);
            this.panel1.Controls.Add(this.txtCausaProb);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.txtNoAeT2);
            this.panel1.Controls.Add(this.txtNoApT1);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(12, 60);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1099, 240);
            this.panel1.TabIndex = 4;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(975, 191);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(64, 17);
            this.label11.TabIndex = 17;
            this.label11.Text = "Teléfono";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(975, 124);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 17);
            this.label10.TabIndex = 16;
            this.label10.Text = "Teléfono";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(716, 196);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 17);
            this.label9.TabIndex = 15;
            this.label9.Text = "Dirección";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(712, 124);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 17);
            this.label8.TabIndex = 14;
            this.label8.Text = "Dirección";
            // 
            // txtTelT2
            // 
            this.txtTelT2.Location = new System.Drawing.Point(933, 162);
            this.txtTelT2.Margin = new System.Windows.Forms.Padding(4);
            this.txtTelT2.MaxLength = 13;
            this.txtTelT2.Name = "txtTelT2";
            this.txtTelT2.Size = new System.Drawing.Size(147, 22);
            this.txtTelT2.TabIndex = 13;
            // 
            // txtDiT2
            // 
            this.txtDiT2.Location = new System.Drawing.Point(647, 162);
            this.txtDiT2.Margin = new System.Windows.Forms.Padding(4);
            this.txtDiT2.MaxLength = 50;
            this.txtDiT2.Name = "txtDiT2";
            this.txtDiT2.Size = new System.Drawing.Size(251, 22);
            this.txtDiT2.TabIndex = 12;
            // 
            // txtTelT1
            // 
            this.txtTelT1.Location = new System.Drawing.Point(933, 96);
            this.txtTelT1.Margin = new System.Windows.Forms.Padding(4);
            this.txtTelT1.MaxLength = 13;
            this.txtTelT1.Name = "txtTelT1";
            this.txtTelT1.Size = new System.Drawing.Size(147, 22);
            this.txtTelT1.TabIndex = 11;
            // 
            // txtDiT1
            // 
            this.txtDiT1.Location = new System.Drawing.Point(647, 96);
            this.txtDiT1.Margin = new System.Windows.Forms.Padding(4);
            this.txtDiT1.MaxLength = 50;
            this.txtDiT1.Name = "txtDiT1";
            this.txtDiT1.Size = new System.Drawing.Size(251, 22);
            this.txtDiT1.TabIndex = 10;
            // 
            // txtSintomas
            // 
            this.txtSintomas.Location = new System.Drawing.Point(293, 44);
            this.txtSintomas.Margin = new System.Windows.Forms.Padding(4);
            this.txtSintomas.MaxLength = 400;
            this.txtSintomas.Name = "txtSintomas";
            this.txtSintomas.Size = new System.Drawing.Size(787, 22);
            this.txtSintomas.TabIndex = 9;
            // 
            // txtCausaProb
            // 
            this.txtCausaProb.Location = new System.Drawing.Point(293, 11);
            this.txtCausaProb.Margin = new System.Windows.Forms.Padding(4);
            this.txtCausaProb.MaxLength = 100;
            this.txtCausaProb.Name = "txtCausaProb";
            this.txtCausaProb.Size = new System.Drawing.Size(787, 22);
            this.txtCausaProb.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(243, 196);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(137, 17);
            this.label7.TabIndex = 7;
            this.label7.Text = "Nombres y Apellidos";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(239, 124);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(137, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "Nombres y Apellidos";
            // 
            // txtNoAeT2
            // 
            this.txtNoAeT2.Location = new System.Drawing.Point(128, 162);
            this.txtNoAeT2.Margin = new System.Windows.Forms.Padding(4);
            this.txtNoAeT2.MaxLength = 50;
            this.txtNoAeT2.Name = "txtNoAeT2";
            this.txtNoAeT2.Size = new System.Drawing.Size(485, 22);
            this.txtNoAeT2.TabIndex = 5;
            // 
            // txtNoApT1
            // 
            this.txtNoApT1.Location = new System.Drawing.Point(128, 96);
            this.txtNoApT1.Margin = new System.Windows.Forms.Padding(4);
            this.txtNoApT1.MaxLength = 50;
            this.txtNoApT1.Name = "txtNoApT1";
            this.txtNoApT1.Size = new System.Drawing.Size(485, 22);
            this.txtNoApT1.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(4, 96);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 34);
            this.label5.TabIndex = 3;
            this.label5.Text = "Informantes o \r\nTestigos";
            // 
            // txtIdCab
            // 
            this.txtIdCab.Location = new System.Drawing.Point(113, 7);
            this.txtIdCab.Margin = new System.Windows.Forms.Padding(4);
            this.txtIdCab.Name = "txtIdCab";
            this.txtIdCab.Size = new System.Drawing.Size(144, 22);
            this.txtIdCab.TabIndex = 7;
            // 
            // btnWard4
            // 
            this.btnWard4.Location = new System.Drawing.Point(904, 353);
            this.btnWard4.Margin = new System.Windows.Forms.Padding(4);
            this.btnWard4.Name = "btnWard4";
            this.btnWard4.Size = new System.Drawing.Size(199, 28);
            this.btnWard4.TabIndex = 8;
            this.btnWard4.Text = "GUARDAR Y SEGUIR";
            this.btnWard4.UseVisualStyleBackColor = true;
            this.btnWard4.Click += new System.EventHandler(this.btnWard4_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.txtIdCab);
            this.panel2.Location = new System.Drawing.Point(835, 11);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(276, 46);
            this.panel2.TabIndex = 9;
            // 
            // btnRegresaala3
            // 
            this.btnRegresaala3.Location = new System.Drawing.Point(20, 353);
            this.btnRegresaala3.Margin = new System.Windows.Forms.Padding(4);
            this.btnRegresaala3.Name = "btnRegresaala3";
            this.btnRegresaala3.Size = new System.Drawing.Size(136, 28);
            this.btnRegresaala3.TabIndex = 10;
            this.btnRegresaala3.Text = "REGRESAR";
            this.btnRegresaala3.UseVisualStyleBackColor = true;
            this.btnRegresaala3.Click += new System.EventHandler(this.btnRegresaala3_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::AppDefuncionGeneral.Properties.Resources.Creative_Tumblr_Backgrounds_2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1136, 410);
            this.Controls.Add(this.btnRegresaala3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnWard4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form4";
            this.Text = "Registro";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtTelT2;
        private System.Windows.Forms.TextBox txtDiT2;
        private System.Windows.Forms.TextBox txtTelT1;
        private System.Windows.Forms.TextBox txtDiT1;
        private System.Windows.Forms.TextBox txtSintomas;
        private System.Windows.Forms.TextBox txtCausaProb;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtNoAeT2;
        private System.Windows.Forms.TextBox txtNoApT1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtIdCab;
        private System.Windows.Forms.Button btnWard4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnRegresaala3;
    }
}