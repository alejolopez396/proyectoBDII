﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppDefuncionGeneral
{
    public partial class Form6 : Form
    {

        

    
        


        public Form6()
        {
            InitializeComponent();
             
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            




        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form vistas= new Form7();
            this.Hide();
            vistas.ShowDialog();
            this.Close();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form launo = new Form1();
            this.Hide();
            launo.ShowDialog();
            this.Close(); 
        
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form audi = new Form9();
            this.Hide();
            audi.ShowDialog();
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
