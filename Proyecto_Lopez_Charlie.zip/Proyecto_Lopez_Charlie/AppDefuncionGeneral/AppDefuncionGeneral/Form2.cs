﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppDefuncionGeneral
{
    public partial class Form2 : Form
    {

        ConexionDatosFalle datosFalle = new ConexionDatosFalle(); 
        

        public Form2()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbNaciona.SelectedIndex == 1) {
                txtNomPais.Enabled = true; 
            }

            if (cmbNaciona.SelectedIndex == 0) {
                txtNomPais.Text = ""; 
                txtNomPais.Enabled = false;
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label23_Click(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

            //AQUI SE EJECUTA CON EL PARAMETRO A LLENAR TIPO COMBO 
            datosFalle.llenarComboProvincias(cmbProv);
            datosFalle.llenarComboEstado(cmbEstado);
            datosFalle.llenarComboSexo(cmbSexo);
            cmbNaciona.Items.Add("Nacional");
            cmbNaciona.Items.Add("Extranjero");
            cmbLeerEscri.Items.Add("Si");
            cmbLeerEscri.Items.Add("No");
            txtNomPais.Enabled = false;
            datosFalle.llenarLugarOcu(cmbOcurrencia);
            datosFalle.llenarInstruc(cmbNivInstr);
            datosFalle.llenarEtni(cmbAutoId); 


        }

        private void button1_Click(object sender, EventArgs e)
        {
            int numSexo = cmbSexo.SelectedIndex + 1;
            int numNacio = cmbNaciona.SelectedIndex + 1;
            int numEstado = cmbEstado.SelectedIndex + 1;
            int numleerEscr = cmbLeerEscri.SelectedIndex;
            int numnive = cmbNivInstr.SelectedIndex + 1;
            int numProv = cmbProv.SelectedIndex + 1;
            int numEtni = cmbAutoId.SelectedIndex + 1;
            int numlug = cmbOcurrencia.SelectedIndex + 1; 
            
            if (datosFalle.validarDatosFalle(Convert.ToString(txtCi.Text)) == 0)
            {
               MessageBox.Show(datosFalle.insertarDatosFallecido(Convert.ToInt32(txtID.Text), Convert.ToInt32(txtIdCAB.Text), txtNomApel.Text, numNacio, txtNomPais.Text, txtCi.Text, numSexo, dtpNac.Text,
                   dtpFalle.Text, Convert.ToInt32(txtHoras.Text),Convert.ToInt32(txtDias.Text),
                   Convert.ToInt32(txtMeses.Text), Convert.ToInt32(txtAnios.Text), numProv, txtCant.Text,
                   txtParro.Text, txtLocal.Text, txtDire.Text, Convert.ToInt32(txtInec.Text), 
                   Convert.ToInt32(txtInecLoca.Text), numEstado, numleerEscr, numnive, numEtni, numlug));

                txtID.Text = "";
                txtIdCAB.Text = "";
                txtNomApel.Text = "";
                txtHoras.Text = "";
                txtDias.Text = "";
                txtMeses.Text = "";
                txtAnios.Text = "";
                txtCant.Text = ""; 
                txtParro.Text = "";
                txtLocal.Text = ""; 
                txtInec.Text = ""; 
                txtInecLoca.Text = "";
                txtDire.Text = "";
                txtNomPais.Text = "";
                txtCi.Text = "";


                Form ParteB = new Form3();
                this.Hide();
                ParteB.ShowDialog();
                this.Close(); 



            }
            else
            {
                MessageBox.Show("ESTE REGISTRO YA EXISTE");
                txtIdCAB.Text = "";
                txtCi.Text = "";
                txtID.Text = ""; 

            }



        }
    }
}
