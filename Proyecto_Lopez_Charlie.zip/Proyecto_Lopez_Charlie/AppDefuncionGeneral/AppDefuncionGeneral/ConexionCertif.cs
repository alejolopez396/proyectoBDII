﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Forms; 



namespace AppDefuncionGeneral
{
    class ConexionCertif
    {
        SqlConnection cn;
        SqlCommand cmd;
        SqlDataReader dr;


        //CONEXION DE LA BASE DE DATOS...
        public ConexionCertif() {

            try
            {
                cn = new SqlConnection("Data Source=LAPTOP-NND7KTNQ\\SQLEXPRESS;Initial Catalog=DefuncionGeneral;Integrated Security=True");
                cn.Open();
                Console.WriteLine("LA BASE DE DATOS ESTA CONECTADA");
            }
            catch (Exception ex)
            {
                MessageBox.Show("LA BASE DE DATOS NO SE A CONECTADO: " + ex.ToString());
            }


        }


        //LLENAR COMBOS..
        //LLENAR COMBO DE MORTALIDAD MATERNA.. 

        public void llenarComboMortalidadMaterna(ComboBox cmb)
        {
            try
            {
                cmd = new SqlCommand("select PeriodoMuerte from Mor_Materna", cn);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cmb.Items.Add(dr["PeriodoMuerte"].ToString());
                }
                dr.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("NO SE LLENO EL COMBO" + ex.ToString());
            }
        }



        //LLENAR COMBO MUERTES VIOLENTAS... 

        public void llenarComboMuerViol(ComboBox cmb)
        {
            try
            {
                cmd = new SqlCommand("select tipo from muerte_acc_vio", cn);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cmb.Items.Add(dr["tipo"].ToString());
                }
                dr.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("NO SE LLENO EL COMBO" + ex.ToString());
            }
        }

        //LLENAR COMBO LUGAR

        public void llenarComboLugar(ComboBox cmb)
        {
            try
            {
                cmd = new SqlCommand("select lugar from lugar_muerte_violenta", cn);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cmb.Items.Add(dr["lugar"].ToString());
                }
                dr.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("NO SE LLENO EL COMBO" + ex.ToString());
            }
        }

        //INSERT EN LA TABLA CERTIFICADO

        public string insertarCertificado(int num, string CA, string CB, string CC, string CD, int TA, int TB, int TC, int TD, int CoA, int CoB, int CoC, int CoD, string OtraCaus, int TOtra, int Inec,int MorM, int muerV, int lug, string Desc, int aut)
        {
            string salida = "REGISTRO EXITOSO :D";
            try
            {
                cmd = new SqlCommand("insert into certif_def (num_form, causaA, causaB, causaC, causaD, tiempoA, tiempoB, tiempoC, tiempoD, codigoA, codigoB, codigoC, codigoD, otraCausa, tiempoOtraCausa, cod_causa_basi, id_morma, id_muerte, id_lug, descripcion, autopsia) values ("+num+", '"+CA+"', '"+CB+"', '"+CC+"', '"+CD+"', "+TA+", "+TB+", "+TC+","+TD+", "+CoA+", "+CoB+", "+CoC+", "+CoD+", '"+OtraCaus+"', "+TOtra+", "+Inec+", "+MorM+", "+muerV+", "+lug+", '"+Desc+"', "+aut+" )", cn);
                cmd.ExecuteNonQuery();


            }
            catch (Exception ex)
            {
                salida = "NO SE INSERTARON LOS DATOS D:" + ex.ToString();
            }
            return salida;
        }

        //VERIFICAR SI EXISTE ESTE VALOR EN LA TABLA....

        public int validarDatosCERT(int cod_causa)
        {
            int contador = 0;
            try
            {
                cmd = new SqlCommand("select * from certif_def where cod_causa_basi like " + cod_causa + "", cn);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    contador++;
                }
                dr.Close();



            }
            catch (Exception ex)
            {
                MessageBox.Show("No se puede realizar la consulta de verificacion: " + ex.ToString());
            }
            return contador;
        }







    }
}
