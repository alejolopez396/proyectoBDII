﻿namespace AppDefuncionGeneral
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNomApel = new System.Windows.Forms.TextBox();
            this.txtNomPais = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbNaciona = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cmbOcurrencia = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.cmbEstado = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.dtpFalle = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.dtpNac = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbSexo = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCi = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label28 = new System.Windows.Forms.Label();
            this.cmbNivInstr = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.cmbLeerEscri = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtAnios = new System.Windows.Forms.TextBox();
            this.txtMeses = new System.Windows.Forms.TextBox();
            this.txtDias = new System.Windows.Forms.TextBox();
            this.txtHoras = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.cmbAutoId = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtInecLoca = new System.Windows.Forms.TextBox();
            this.txtInec = new System.Windows.Forms.TextBox();
            this.txtDire = new System.Windows.Forms.TextBox();
            this.txtLocal = new System.Windows.Forms.TextBox();
            this.txtParro = new System.Windows.Forms.TextBox();
            this.txtCant = new System.Windows.Forms.TextBox();
            this.cmbProv = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtIdCAB = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 16);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(281, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "(A) DATOS DEL FALLECIDO O FALLECIDA";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(-4, 21);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(195, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "5) NOMBRES Y APELLIDOS: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(609, 21);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(134, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "6) NACIONALIDAD: ";
            // 
            // txtNomApel
            // 
            this.txtNomApel.Location = new System.Drawing.Point(4, 41);
            this.txtNomApel.Margin = new System.Windows.Forms.Padding(4);
            this.txtNomApel.MaxLength = 80;
            this.txtNomApel.Name = "txtNomApel";
            this.txtNomApel.Size = new System.Drawing.Size(577, 22);
            this.txtNomApel.TabIndex = 3;
            // 
            // txtNomPais
            // 
            this.txtNomPais.Location = new System.Drawing.Point(757, 62);
            this.txtNomPais.Margin = new System.Windows.Forms.Padding(4);
            this.txtNomPais.MaxLength = 40;
            this.txtNomPais.Name = "txtNomPais";
            this.txtNomPais.Size = new System.Drawing.Size(245, 22);
            this.txtNomPais.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(841, 16);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "N° Cabecera";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // cmbNaciona
            // 
            this.cmbNaciona.FormattingEnabled = true;
            this.cmbNaciona.Location = new System.Drawing.Point(757, 17);
            this.cmbNaciona.Margin = new System.Windows.Forms.Padding(4);
            this.cmbNaciona.Name = "cmbNaciona";
            this.cmbNaciona.Size = new System.Drawing.Size(245, 24);
            this.cmbNaciona.TabIndex = 6;
            this.cmbNaciona.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(637, 70);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(112, 17);
            this.label5.TabIndex = 7;
            this.label5.Text = "Nombre del Pais";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.cmbNaciona);
            this.panel1.Controls.Add(this.txtNomApel);
            this.panel1.Controls.Add(this.txtNomPais);
            this.panel1.Location = new System.Drawing.Point(21, 58);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1104, 100);
            this.panel1.TabIndex = 8;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.cmbOcurrencia);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Controls.Add(this.cmbEstado);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.dtpFalle);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.dtpNac);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.cmbSexo);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.txtCi);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Location = new System.Drawing.Point(21, 165);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(385, 498);
            this.panel2.TabIndex = 9;
            // 
            // cmbOcurrencia
            // 
            this.cmbOcurrencia.FormattingEnabled = true;
            this.cmbOcurrencia.Location = new System.Drawing.Point(13, 460);
            this.cmbOcurrencia.Margin = new System.Windows.Forms.Padding(4);
            this.cmbOcurrencia.Name = "cmbOcurrencia";
            this.cmbOcurrencia.Size = new System.Drawing.Size(299, 24);
            this.cmbOcurrencia.TabIndex = 11;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(9, 416);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(348, 17);
            this.label27.TabIndex = 10;
            this.label27.Text = "16) LUGAR DE OCURRENCIA DEL FALLECIMIENTO: ";
            // 
            // cmbEstado
            // 
            this.cmbEstado.FormattingEnabled = true;
            this.cmbEstado.Location = new System.Drawing.Point(13, 348);
            this.cmbEstado.Margin = new System.Windows.Forms.Padding(4);
            this.cmbEstado.Name = "cmbEstado";
            this.cmbEstado.Size = new System.Drawing.Size(299, 24);
            this.cmbEstado.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 327);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(238, 17);
            this.label10.TabIndex = 8;
            this.label10.Text = "13) ESTADO CIVIL y/o CONYUGAL: ";
            // 
            // dtpFalle
            // 
            this.dtpFalle.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFalle.Location = new System.Drawing.Point(13, 267);
            this.dtpFalle.Margin = new System.Windows.Forms.Padding(4);
            this.dtpFalle.Name = "dtpFalle";
            this.dtpFalle.Size = new System.Drawing.Size(299, 22);
            this.dtpFalle.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(9, 246);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(220, 17);
            this.label9.TabIndex = 6;
            this.label9.Text = "10) FECHA DE FALLECIMIENTO: ";
            // 
            // dtpNac
            // 
            this.dtpNac.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNac.Location = new System.Drawing.Point(13, 172);
            this.dtpNac.Margin = new System.Windows.Forms.Padding(4);
            this.dtpNac.Name = "dtpNac";
            this.dtpNac.Size = new System.Drawing.Size(299, 22);
            this.dtpNac.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 153);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(189, 17);
            this.label8.TabIndex = 4;
            this.label8.Text = "9) FECHA DE NACIMIENTO: ";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // cmbSexo
            // 
            this.cmbSexo.FormattingEnabled = true;
            this.cmbSexo.Location = new System.Drawing.Point(13, 96);
            this.cmbSexo.Margin = new System.Windows.Forms.Padding(4);
            this.cmbSexo.Name = "cmbSexo";
            this.cmbSexo.Size = new System.Drawing.Size(299, 24);
            this.cmbSexo.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 76);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 17);
            this.label7.TabIndex = 2;
            this.label7.Text = "8) SEXO: ";
            // 
            // txtCi
            // 
            this.txtCi.Location = new System.Drawing.Point(13, 25);
            this.txtCi.Margin = new System.Windows.Forms.Padding(4);
            this.txtCi.MaxLength = 13;
            this.txtCi.Name = "txtCi";
            this.txtCi.Size = new System.Drawing.Size(303, 22);
            this.txtCi.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 5);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(300, 17);
            this.label6.TabIndex = 0;
            this.label6.Text = "7) CEDULA DE CIUDADANIA O PASAPORTE: ";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label28);
            this.panel3.Controls.Add(this.cmbNivInstr);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.cmbLeerEscri);
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.txtAnios);
            this.panel3.Controls.Add(this.txtMeses);
            this.panel3.Controls.Add(this.txtDias);
            this.panel3.Controls.Add(this.txtHoras);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Location = new System.Drawing.Point(415, 165);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(356, 498);
            this.panel3.TabIndex = 10;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(7, 34);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(318, 15);
            this.label28.TabIndex = 14;
            this.label28.Text = "(Solo llene uno de los campos los demas pongalos en 0)";
            // 
            // cmbNivInstr
            // 
            this.cmbNivInstr.FormattingEnabled = true;
            this.cmbNivInstr.Location = new System.Drawing.Point(37, 460);
            this.cmbNivInstr.Margin = new System.Windows.Forms.Padding(4);
            this.cmbNivInstr.Name = "cmbNivInstr";
            this.cmbNivInstr.Size = new System.Drawing.Size(307, 24);
            this.cmbNivInstr.TabIndex = 13;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(33, 416);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(300, 17);
            this.label18.TabIndex = 12;
            this.label18.Text = "14.2) NIVEL DE INSTRUCCION ALCANZADO: ";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(33, 327);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(223, 17);
            this.label17.TabIndex = 11;
            this.label17.Text = "14.1) ¿SABIA LEER Y ESCRIBIR? ";
            // 
            // cmbLeerEscri
            // 
            this.cmbLeerEscri.FormattingEnabled = true;
            this.cmbLeerEscri.Location = new System.Drawing.Point(37, 364);
            this.cmbLeerEscri.Margin = new System.Windows.Forms.Padding(4);
            this.cmbLeerEscri.Name = "cmbLeerEscri";
            this.cmbLeerEscri.Size = new System.Drawing.Size(307, 24);
            this.cmbLeerEscri.TabIndex = 10;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(5, 295);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(246, 17);
            this.label16.TabIndex = 9;
            this.label16.Text = "14) ALFABETISMO E INSTRUCCIÓN: ";
            // 
            // txtAnios
            // 
            this.txtAnios.Location = new System.Drawing.Point(160, 207);
            this.txtAnios.Margin = new System.Windows.Forms.Padding(4);
            this.txtAnios.MaxLength = 3;
            this.txtAnios.Name = "txtAnios";
            this.txtAnios.Size = new System.Drawing.Size(132, 22);
            this.txtAnios.TabIndex = 8;
            // 
            // txtMeses
            // 
            this.txtMeses.Location = new System.Drawing.Point(160, 161);
            this.txtMeses.Margin = new System.Windows.Forms.Padding(4);
            this.txtMeses.MaxLength = 2;
            this.txtMeses.Name = "txtMeses";
            this.txtMeses.Size = new System.Drawing.Size(132, 22);
            this.txtMeses.TabIndex = 7;
            // 
            // txtDias
            // 
            this.txtDias.Location = new System.Drawing.Point(160, 113);
            this.txtDias.Margin = new System.Windows.Forms.Padding(4);
            this.txtDias.MaxLength = 1;
            this.txtDias.Name = "txtDias";
            this.txtDias.Size = new System.Drawing.Size(132, 22);
            this.txtDias.TabIndex = 6;
            // 
            // txtHoras
            // 
            this.txtHoras.Location = new System.Drawing.Point(160, 73);
            this.txtHoras.Margin = new System.Windows.Forms.Padding(4);
            this.txtHoras.MaxLength = 2;
            this.txtHoras.Name = "txtHoras";
            this.txtHoras.Size = new System.Drawing.Size(132, 22);
            this.txtHoras.TabIndex = 5;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(33, 207);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(117, 17);
            this.label15.TabIndex = 4;
            this.label15.Text = "Años Cumplidos: ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(33, 161);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(78, 17);
            this.label14.TabIndex = 3;
            this.label14.Text = "En Meses: ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(33, 112);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 17);
            this.label13.TabIndex = 2;
            this.label13.Text = "En Dias: ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(33, 73);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(79, 17);
            this.label12.TabIndex = 1;
            this.label12.Text = "En Horas:  ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(5, 5);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(174, 17);
            this.label11.TabIndex = 0;
            this.label11.Text = "11) EDAD AL FALLECER: ";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label30);
            this.panel4.Controls.Add(this.label31);
            this.panel4.Controls.Add(this.cmbAutoId);
            this.panel4.Controls.Add(this.label26);
            this.panel4.Controls.Add(this.label25);
            this.panel4.Controls.Add(this.label24);
            this.panel4.Controls.Add(this.txtInecLoca);
            this.panel4.Controls.Add(this.txtInec);
            this.panel4.Controls.Add(this.txtDire);
            this.panel4.Controls.Add(this.txtLocal);
            this.panel4.Controls.Add(this.txtParro);
            this.panel4.Controls.Add(this.txtCant);
            this.panel4.Controls.Add(this.cmbProv);
            this.panel4.Controls.Add(this.label23);
            this.panel4.Controls.Add(this.label22);
            this.panel4.Controls.Add(this.label21);
            this.panel4.Controls.Add(this.label20);
            this.panel4.Controls.Add(this.label19);
            this.panel4.Location = new System.Drawing.Point(779, 165);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(347, 498);
            this.panel4.TabIndex = 11;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(255, 287);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(62, 17);
            this.label30.TabIndex = 20;
            this.label30.Text = "OFIC. Nº";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(88, 287);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(73, 17);
            this.label31.TabIndex = 19;
            this.label31.Text = "USO INEC";
            // 
            // cmbAutoId
            // 
            this.cmbAutoId.FormattingEnabled = true;
            this.cmbAutoId.Location = new System.Drawing.Point(8, 460);
            this.cmbAutoId.Margin = new System.Windows.Forms.Padding(4);
            this.cmbAutoId.Name = "cmbAutoId";
            this.cmbAutoId.Size = new System.Drawing.Size(311, 24);
            this.cmbAutoId.TabIndex = 15;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(9, 395);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(310, 51);
            this.label26.TabIndex = 14;
            this.label26.Text = "DE ACUERDO CON LA CULTURA Y\r\nCOSTUMBRES, CÓMO SE AUTOIDENTIFICABA\r\nEL FALLECIDO (" +
    "A) ?  ";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(4, 374);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(231, 17);
            this.label25.TabIndex = 13;
            this.label25.Text = "15) AUTOIDENTIFICACION ÉTNICA";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(5, 1);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(318, 17);
            this.label24.TabIndex = 12;
            this.label24.Text = "12) RESIDENCIA HABITUAL DEL FALLECIDO (A)";
            // 
            // txtInecLoca
            // 
            this.txtInecLoca.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtInecLoca.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtInecLoca.Location = new System.Drawing.Point(248, 308);
            this.txtInecLoca.Margin = new System.Windows.Forms.Padding(4);
            this.txtInecLoca.MaxLength = 3;
            this.txtInecLoca.Name = "txtInecLoca";
            this.txtInecLoca.Size = new System.Drawing.Size(69, 22);
            this.txtInecLoca.TabIndex = 11;
            // 
            // txtInec
            // 
            this.txtInec.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtInec.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtInec.Location = new System.Drawing.Point(5, 308);
            this.txtInec.Margin = new System.Windows.Forms.Padding(4);
            this.txtInec.MaxLength = 6;
            this.txtInec.Name = "txtInec";
            this.txtInec.Size = new System.Drawing.Size(233, 22);
            this.txtInec.TabIndex = 10;
            // 
            // txtDire
            // 
            this.txtDire.Location = new System.Drawing.Point(5, 246);
            this.txtDire.Margin = new System.Windows.Forms.Padding(4);
            this.txtDire.MaxLength = 50;
            this.txtDire.Name = "txtDire";
            this.txtDire.Size = new System.Drawing.Size(312, 22);
            this.txtDire.TabIndex = 9;
            this.txtDire.TextChanged += new System.EventHandler(this.textBox12_TextChanged);
            // 
            // txtLocal
            // 
            this.txtLocal.Location = new System.Drawing.Point(4, 198);
            this.txtLocal.Margin = new System.Windows.Forms.Padding(4);
            this.txtLocal.MaxLength = 50;
            this.txtLocal.Name = "txtLocal";
            this.txtLocal.Size = new System.Drawing.Size(313, 22);
            this.txtLocal.TabIndex = 8;
            // 
            // txtParro
            // 
            this.txtParro.Location = new System.Drawing.Point(4, 149);
            this.txtParro.Margin = new System.Windows.Forms.Padding(4);
            this.txtParro.MaxLength = 50;
            this.txtParro.Name = "txtParro";
            this.txtParro.Size = new System.Drawing.Size(315, 22);
            this.txtParro.TabIndex = 7;
            // 
            // txtCant
            // 
            this.txtCant.Location = new System.Drawing.Point(4, 96);
            this.txtCant.Margin = new System.Windows.Forms.Padding(4);
            this.txtCant.MaxLength = 50;
            this.txtCant.Name = "txtCant";
            this.txtCant.Size = new System.Drawing.Size(316, 22);
            this.txtCant.TabIndex = 6;
            // 
            // cmbProv
            // 
            this.cmbProv.FormattingEnabled = true;
            this.cmbProv.Location = new System.Drawing.Point(4, 47);
            this.cmbProv.Margin = new System.Windows.Forms.Padding(4);
            this.cmbProv.Name = "cmbProv";
            this.cmbProv.Size = new System.Drawing.Size(316, 24);
            this.cmbProv.TabIndex = 5;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(99, 226);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(141, 17);
            this.label23.TabIndex = 4;
            this.label23.Text = "Direccion domiciliaria";
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(137, 177);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(69, 17);
            this.label22.TabIndex = 3;
            this.label22.Text = "Localidad";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(99, 126);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(164, 17);
            this.label21.TabIndex = 2;
            this.label21.Text = "Parroquia urbana o rural";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(141, 76);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 17);
            this.label20.TabIndex = 1;
            this.label20.Text = "Cantón";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(140, 28);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(66, 17);
            this.label19.TabIndex = 0;
            this.label19.Text = "Provincia";
            // 
            // txtIdCAB
            // 
            this.txtIdCAB.Location = new System.Drawing.Point(940, 12);
            this.txtIdCAB.Margin = new System.Windows.Forms.Padding(4);
            this.txtIdCAB.Name = "txtIdCAB";
            this.txtIdCAB.Size = new System.Drawing.Size(84, 22);
            this.txtIdCAB.TabIndex = 12;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(857, 678);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(240, 28);
            this.button1.TabIndex = 13;
            this.button1.Text = "GUARDAR Y SEGUIR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(689, 16);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(29, 17);
            this.label29.TabIndex = 14;
            this.label29.Text = "ID: ";
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(741, 12);
            this.txtID.Margin = new System.Windows.Forms.Padding(4);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(79, 22);
            this.txtID.TabIndex = 15;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::AppDefuncionGeneral.Properties.Resources.Creative_Tumblr_Backgrounds_2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1140, 721);
            this.Controls.Add(this.txtID);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtIdCAB);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form2";
            this.Text = "Registro";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNomApel;
        private System.Windows.Forms.TextBox txtNomPais;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbNaciona;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbSexo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCi;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtIdCAB;
        private System.Windows.Forms.ComboBox cmbEstado;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dtpFalle;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dtpNac;
        private System.Windows.Forms.ComboBox cmbNivInstr;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cmbLeerEscri;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtAnios;
        private System.Windows.Forms.TextBox txtMeses;
        private System.Windows.Forms.TextBox txtDias;
        private System.Windows.Forms.TextBox txtHoras;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtLocal;
        private System.Windows.Forms.TextBox txtParro;
        private System.Windows.Forms.TextBox txtCant;
        private System.Windows.Forms.ComboBox cmbProv;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox cmbOcurrencia;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox cmbAutoId;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtInecLoca;
        private System.Windows.Forms.TextBox txtInec;
        private System.Windows.Forms.TextBox txtDire;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
    }
}