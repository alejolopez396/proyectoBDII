﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppDefuncionGeneral
{
    public partial class Form5 : Form
    {
        ConexionInscrip coneIns = new ConexionInscrip(); 



        public Form5()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Form5_Load(object sender, EventArgs e)
        {
            coneIns.llenarComboCert(cmbCertificado);
            coneIns.llenarParent(cmbParent);
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void btnWARD5_Click(object sender, EventArgs e)
        {

            int numCert = cmbCertificado.SelectedIndex + 1;
            int numPare = cmbParent.SelectedIndex + 1;

            try
            {

                MessageBox.Show(coneIns.insertarDatosInse(Convert.ToInt32(txtIdCabe.Text), numCert, txtNomApelCertificador.Text, txtCiCerti.Text, txtDirCerti.Text, txtTelfCerti.Text, txtNom_apel.Text, Convert.ToInt32(txtEdad.Text), numPare, txtObser.Text));


                Form vuelve1 = new Form6();
                this.Hide();
                vuelve1.ShowDialog();
                this.Close();
            }
            catch (Exception ex) {
                MessageBox.Show("ERROR AL INSERTAR DATOS, Pruebe el reingreso correcto de los mismos" + ex.ToString()); 
            }


        }
    }
}
