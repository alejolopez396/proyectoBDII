﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppDefuncionGeneral
{
    public partial class Form4 : Form
    {
        ConexionNOcert ConexionNoC = new ConexionNOcert(); 

        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
           
        }
       
        private void cmbValidacion_SelectedIndexChanged(object sender, EventArgs e)
        {
           
     
        }

        private void btnWard4_Click(object sender, EventArgs e)
        {
            try
            {
               
                MessageBox.Show(ConexionNoC.insertarDatosFallecido(Convert.ToInt32(txtIdCab.Text), txtCausaProb.Text, txtSintomas.Text, txtNoApT1.Text, txtNoAeT2.Text, txtDiT1.Text, txtDiT2.Text, txtTelT1.Text, txtTelT2.Text));
                //AQUI VA LA FORM 5

                Form ParteC = new Form5();
                this.Hide();
                ParteC.ShowDialog();
                this.Close();

            }
            catch (Exception ex) {
                MessageBox.Show("ERROR AL INSERTAR LOS DATOS" + ex.ToString());
            }
            

        }

        private void btnRegresaala3_Click(object sender, EventArgs e)
        {
            Form ParteB = new Form3();
            this.Hide();
            ParteB.ShowDialog();
            this.Close();
        }
    }
}
