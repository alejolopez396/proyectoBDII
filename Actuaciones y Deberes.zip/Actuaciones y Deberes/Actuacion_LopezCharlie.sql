
use Hospital_BD

select * from Doctor

begin tran insertDoctor
declare @num int
insert into Doctor(Doctor_No,Hospital_Cod,Apellido, Especialidad) values (890,22,'Alejo L','Otorrinonaringologia')

commit tran insertDoctor
rollback tran insertDoctor

/*aceptar una transaccion*/

select * from Emp
begin transaction 
	delete from Emp where Emp_No = 7369
commit
select * from Emp

/*---------------revertir transaccion-----------*/
begin transaction
	delete from Emp where Emp_No = 7521
rollback transaction

select * from Emp


/*detectar transacciones*/
begin transaction
	begin try
		
		insert into Emp values(7622,'NU�EZ','VENDEDOR',4273,'14-12-2018',39892,0,10)
		commit tran
	end try
	begin catch
		rollback tran
	end catch
select * from Emp

