---TRANSACCIONES EXPLICITA
---ACEPTAR UNA TRANSACCI�N

SELECT * FROM queja
BEGIN TRANSACTION
	DELETE FROM queja WHERE id_quej=1
COMMIT
SELECT * FROM queja

/*
	EXPLICACION:
	La transaccion esta eliminando la queja con identificador 1 que 
	se encuentre en la tabla queja, y al final se confirma el cambio 
	con un commit
*/

---REVERTIR UNA TRANSACCI�N
BEGIN TRANSACTION
	DELETE FROM queja WHERE id_quej=3
ROLLBACK
SELECT * FROM queja

/*

	EXPLICACION:
	La transaccion indica que se eliminara la queja numero 3 de la tabla queja, 
	sin embargo el comando ROLLBACK da la opcion de cancelar el cambio

*/


BEGIN TRANSACTION
	INSERT INTO empleado VALUES('EMPLEADO NUEVO')
	INSERT INTO sucursal VALUES ('SUCURSAL NUEVA')
ROLLBACK
SELECT * FROM empleado
SELECT * FROM sucursal

/*

	EXPLICACION:
	La transaccion permite insertar un dato en la tabla empleado
	y un dato en la tabla sucursal, pero el comando ROLLBACK cancela este cambio, 
	con lo cual no se insertaran los datos

*/


---ASIGNAR NOMBRE A UNA TRANSACCI�N USANDO VARIABLES
DECLARE @nombreTran VARCHAR(10)
SELECT @nombreTran = 'transaccion1'
BEGIN TRANSACTION @nombreTran
	DELETE FROM queja WHERE id_quej=3
COMMIT TRANSACTION @nombreTran	 

/*

	EXPLICACION:
	Esta transaccion elimina la queja tres de la tabla queja y CONFIRMA el cambio, 
	sin posibilidad de revertir.

	Lo unico que diferencia a la transaccion ACEPTAR es que se a�aden un nombre a la transaccion
	por medio de una variable que le asigna el nombre.

*/


SELECT * FROM queja
DECLARE @nombreTran VARCHAR(10)
SELECT @nombreTran = 'transaccion2'
BEGIN TRANSACTION @nombreTran
	DELETE FROM queja WHERE id_quej=7
ROLLBACK TRANSACTION @nombreTran	 

/*

	EXPLICACION:
	a esta transaccion se le asgina el nombre transaccion 2 por medio de una variable
	y lo que realiza es eliminar la queja numero 7 con posibilidad de deshacer el 
	cambio llamando al nombre de la transaccion

*/


--DETECTAR ERRORES
BEGIN TRANSACTION
	BEGIN TRY
		INSERT INTO empleado VALUES('EMPLEADO ok1')
		INSERT INTO empleado VALUES(200,'EMPLEADO NUEVO')
		COMMIT TRAN
	END TRY
	BEGIN CATCH
		ROLLBACK TRAN
	END CATCH
SELECT * FROM empleado	

/*

	EXPLICACION: 
	La transaccion inserta dos datos en los cuales el primer dato se presentan con error 
	en sus parametros y en el segundo se presentan datos insertados de manera correcta, en
	lo que se confirma el cambio, se crea un try y un catch como condicion para indicar que 
	existe un error de parametros.

*/

--PUNTOS DE RESTAURACI�N

BEGIN TRAN INSERTAQUEJA
      UPDATE queja
            SET id_empl_ac = 10 WHERE id_quej=15
      SAVE TRAN P1
      UPDATE queja
            SET id_empl_ac = 20 WHERE id_quej=15
      ROLLBACK TRAN P1
COMMIT TRAN INSERTAQUEJA
SELECT id_empl_ac FROM queja WHERE id_quej=15

/*

	EXPLICACION: 
	La transaccion indica que se va a actualizar la tabla queja cuando se reemplace el id del empleado 10 
	en la queja numero 15 de la tabla queja y a continuacion se actualizara de nuevo el id del empelado en el 
	mismo numero de queja mencionado anteriormente.

*/



--TRANSACCIONES IMPLICITAS

 SET IMPLICIT_TRANSACTIONS ON
	insert into motivo_queja values('nuevo motivo',2)
 ROLLBACK
 SET IMPLICIT_TRANSACTIONS ON
	insert into motivo_queja values('nuevo motivo commit',2)
 COMMIT

 /*
 
	EXPLICACION: Primero se va a insertar un nuevo registro en la tabla motivo queja,
	con los datos de nuevo y el dientificador dos, pero luego se ejecuta un ROLLBACK el
	cual va a deshacer este cambio, y va a colocar un nuevo valor llamado "nuevo motivo 
	commit", y este sera guardado definitivamente.

 
 */


 ------------------


 /*TRANSACCIONES*/
select * from Region
insert into Region(RegionID,RegionDescription)
values(8,'Pichincha')

/*PARA ACTIVAR EL MODO DE TRANSACCIONES IMPLICITAS*/
SET IMPLICIT_TRANSACTIONS ON

/*para desactivar el modo de transacciones implicitas*/
SET IMPLICIT_TRANSACTIONS OFF
BEGIN TRAN
DELETE FROM Region WHERE RegionDescription='Costa' 

COMMIT;

/*

	EXPLICACION: La transaccion elimina el registro de la tabla Region, 
	cuyo nombre sea "COSTA", y al final se guardan los cambios permanentemente

*/



CREATE TABLE VALUE_TABLE (ID INT);
BEGIN TRAN
INSERT INTO VALUE_TABLE VALUES(1);
INSERT INTO VALUE_TABLE VALUES (2);
SELECT * FROM VALUE_TABLE
ROLLBACK;

/*

	EXPLICACION: Esta   transaccion permite crear dos registros 
	con valores 1 y 2, y a continuacion se activa el comando ROLLBACK, para 
	deshacer los cambios.

*/


/*deshacer la transaccion hecha anteriormente*/

declare @error int
begin tran
/*iniciamos transaccion*/
update products set unitprice=20
where productname='Chai'

/*ejecutamos la primera sentencia*/
set @error= @@ERROR
/*si exite error almacenamos error
y saltamos al codigo para deshacer la transaccion - GOTO vaya a */
if(@error<>0)goto tratarerror 
/*si la primera sentencia  ejecuta con exito, pasamos a la segunda*/

update products set unitprice=20 
where productname='Chang'

set @error=@@ERROR
/*y si hay error hacemos como antes*/
if (@error<>0)goto tratarerror
/*si llegamos hasta aqui los update se han complementado con exito
y podemos guardar*/
commit tran

/*

	EXPLICACION: 
	Esta transaccion se declara con una variable del tipo int llamada @error, cuya funcion es
	primeramente actualizar el registro llamado Cha1, reemplazando el precio de 20.

	a partir de la ejecucion de la sentencia, se verifica que no exista error, comparando si la
	funcion es diferente cero entonces se procede a ir la transaccion trataerror para deshacer la
	anterior transaccion, caso contrario se reemplaza el valor unitario del producto CHANG y luego se 
	procede a actualizar el valor modificado, y si se vuelve a producir la misma condicion anterior, entonces
	se vuelve a deshacer la anterior transaccion.


*/

tratarerror:
if @@ERROR<>0  
begin
print 'ha ocuurido un error'
rollback tran
end

/*

	EXPLICACION:
	Dentro de la transaccion trataerror se crea una condicion para imprimir un mensaje "ha ocurrido un error",
	y adicional se deshace la transaccion anterior

*/
/*4 TRANSACCIONES INTERNAS Y QUE SE EJECUTEN TODAS*/

DECLARE @ERROR1 INT
BEGIN TRAN
UPDATE Region SET RegionDescription='NUEVA REGION'
WHERE RegionID=8;
SET @ERROR1=@@ERROR/*ERROR DEL SISTEMA*/
IF (@ERROR1<>0)GOTO EMPEZARTRAN
UPDATE Region SET RegionDescription'NUEVA REGION'
WHERE RegionID=5
SET @ERROR1=@@ERROR
IF (@ERROR1<>0)GOTO EMPEZARTRAN
COMMIT TRAN

/*

	EXPLICACION: 
	Al crearse la transaccion, se actualiza la tabla region despues de que se haya modificado el
	registro numero 8, en su descripcion (nueva region).
	Luego la transaccion error para detectar si hubo o no algun error al ingresar el nuevo registro,
	despues se comprueba que el error sea diferente de 0 para modificar la transaccion empezartratar
	caso contrario se actualiza la tabla cuando se haya modificado la descripcion de la region numero 5,
	y luego se impkementa el mensaje de error y se vuelve a analizar la sentencia hasta que se cumpla y final
	mente se guarda permanentemente el registro.

*/


EMPEZARTRAN:
if @@ERROR<>0  
begin
print 'ha ocuurido un error'
rollback tran
end

/*

	EXPLICACION: 
	Se define una transaccion llamada empezartran en la cual se imprimira un mensaje de error
	cuando la variable de error tienda a cero

*/


CREATE TABLE TABLA1(COLUMNA1 VARCHAR(50))
BEGIN TRAN 
INSERT INTO TABLA1 VALUES ('PRIMER VALOR')
SAVE TRAN PUNTO1
INSERT INTO TABLA1 VALUES ('SEGUNDO VALOR')
ROLLBACK TRAN PUNTO1
INSERT INTO TABLA1 VALUES ('TERCER VALOR')
COMMIT TRAN 

SELECT * FROM TABLA1
COLUMNA1

/*

	EXPLICACION:
	Se crea una nueva transaccion donde se insertan tres registros por cada variable que se va implementado 
	y en la cual se guardan los cambios permanentemente

*/