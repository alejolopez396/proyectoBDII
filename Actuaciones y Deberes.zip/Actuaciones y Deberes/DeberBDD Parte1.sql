use quejas
/*1. Crear una vista que me muestre la lista (nombres) 
de los empleados que han
atendido quejas entre el 01/11/2016 y el 15/11/2016, 
con su respectivo c�digo.*/
select * from queja
select * from empleado

go
create view Vista_1
as
select nombre_empl,fecha_quej, fecha_ac 
	from queja, empleado
	where fecha_ac between '01/11/2016' and '15/11/2016'
go
drop view Vista_1 
select * from Vista_1
/*2. Usando la vista del punto 1, crear una nueva vista que 
me muestre los mismos datos, pero con las quejas entre el 
01/11/2016 y el 07/11/2016.
*/
go
create view Vista_2
as
select nombre_empl,fecha_quej, fecha_ac 
	from Vista_1
	where fecha_ac between '01/11/2016' and '07/11/2016'
go
select * from Vista_2
/*3. Crear un procedimiento almacenado que me devuelva 
el n�mero de registros que existen en la vista 
del punto 1 y en la vista del punto 2.*/
go
create procedure NumRegistros
	--@cantidad int = 1000
	as
	select count(Vista_1.nombre_empl), count(Vista_2.nombre_empl) from Vista_1, Vista_2
		where Vista_1.nombre_empl = Vista_2.nombre_empl and
			Vista_1.fecha_quej = Vista_2.fecha_quej and
			Vista_1.fecha_ac = Vista_2.fecha_ac
			
go
execute NumRegistros
drop procedure NumRegistros
