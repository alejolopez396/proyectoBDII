/*Escriba un procedimiento almacenado que reciba como par�metro un c�digo de proveedor y                  (8)
devuelve el n�mero de �rdenes en las que est�n incluidos productos de ese proveedor.
*/

DROP LANGUAGE IF EXISTS plpgsql;
CREATE LANGUAGE plpgsql;

select * from productos;
select * from ordenes;
select * from detalle_ordenes;

create or replace function num_ordene_proveedor(idproo int)returns integer
as $$
      declare
      num int;
      begin
            select count(p.productoid) into num from productos p join detalle_ordenes dor
            on (p.productoid=dor.productoid)join ordenes ord on(ord.ordenid=dor.ordenid)
            where proveedorid=idproo
            group by proveedorid;
            return num;
      end;
$$ LANGUAGE plpgsql;

select num_ordene_proveedor(10)

/*----------------------------------------------------------------------------------------------------*/

/*
Escriba un procedimiento almacenado que reciba como par�metro 
un nombre de una categor�a y      
devuelve el c�digo del producto de esa categor�a 
que tiene m�s unidades vendidas.
*/

select * from categorias;
select * from productos;
select * from detalle_ordenes;

create or replace function mas_vendido (nomCat character(50))returns integer
as $$
      declare
      num int;
      begin
            select p.productoid,sum(cantidad)INTO NUM from productos p join categorias c on (c.categoriaid=p.categoriaid)
            join detalle_ordenes dor on(p.productoid=dor.productoid)
            where c.nombrecat=nomCat
            group by descripcion, p.productoid
            order by sum DESC
            limit 1;
            return num;
      end;
$$LANGUAGE 'plpgsql';

select mas_vendido('CARNICOS')

														 


/*Crear un procedimiento almacenado que reciba como par�metro el nombre del producto y muestre el nombre del producto y la categor�a a la que corresponde. */

select * from productos
select * from categorias														 
										
create or replace function productos_categoria(producto varchar)
RETURNS TABLE (descripcion varchar, nombrecat varchar) 
as $$
begin
FOR descripcion, nombrecat IN 
select productos.descripcion, categorias.nombrecat from productos join categorias on productos.categoriaid = categorias.categoriaid
where productos.descripcion = producto
LOOP
RETURN NEXT;
END LOOP;
return;
end;
$$ language plpgsql;

select productos_categoria('SALAMI DE AJO')
														 
/*Crear un procedimiento almacenado que reciba como par�metro orderid y muestre los nombres de los productos correspondientes. */

select * from detalle_ordenes
select * from productos														 
										
create or replace function ordenes_producto(numero_orden integer)
RETURNS TABLE (ordenid integer, descripcion varchar) 
as $$
begin
FOR ordenid, descripcion IN 
select detalle_ordenes.ordenid, productos.descripcion from detalle_ordenes join productos on productos.productoid = detalle_ordenes.productoid
where detalle_ordenes.ordenid = numero_orden
LOOP
RETURN NEXT;
END LOOP;
return;
end;
$$ language plpgsql;

select ordenes_producto(1)
