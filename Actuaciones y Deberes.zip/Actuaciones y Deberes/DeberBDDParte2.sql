use Northwind


SELECT CAST(table_name as varchar)  FROM INFORMATION_SCHEMA.TABLES


/*parte 2*/
/*1. Crear una vista para mostrar los productos ordenados alfab�ticamente.
*/
go
create view Orden_A_Z
as
select * from  Products
	order by ProductName asc
go

select * from Orden_A_Z
/*2. Crear una vista que me muestre los productos que 
tienen m�s de 20 unidades 
disponibles.
*/
go
create view Produc_mayor_20
as
select * from Products
	where UnitsInStock > 20
go

select * from Produc_mayor_20

/*3. Crear una vista que me muestre el nombre del 
producto y nombre de la categor�a 
de los productos descontinuados.
*/
--SELECT CAST(table_name as varchar)  FROM INFORMATION_SCHEMA.TABLES
go
create view V_name_produc
as
select ProductName,CategoryName from Products, Categories
	where Products.CategoryID =Categories.CategoryID and 
	Discontinued = 1
go
	
select *from V_name_produc

	
/*
4. Crear una vista que me muestre el nombre del producto, Id del proveedor, 
nombre del proveedor, y nombre de la categor�a de los productos que no est�n
descontinuados. */

go 
create view P_noDiscon
as
select ProductName,Products.SupplierID,Suppliers.ContactName,
	CategoryName from Products, Categories,Suppliers
	where Products.CategoryID =Categories.CategoryID and 
	Discontinued = 0	
go

select * from P_noDiscon

SELECT CAST(table_name as varchar)  FROM INFORMATION_SCHEMA.TABLES
/*
5. Usando la vista del punto 4, crear un procedimiento almacenado que me
devuelva todos los datos de la vista, pero para un proveedor espec�fico. */

select ProductName,Suppliers.SupplierID,Suppliers.ContactName,
	CategoryName from Products, Categories,Suppliers
	where Products.CategoryID =Categories.CategoryID and 
	Discontinued = 0 and 
	ContactName like 'Lars Peterson%'

go
create procedure proveedorEspecifico
	@nombre varchar(50)='Lars Peterson'
	as
	select * from P_noDiscon
		where ContactName like @nombre
go

execute proveedorEspecifico
drop procedure proveedorEspecifico

/*
6. Crear una vista que me muestre el n�mero de �rdenes por cliente (id orden, id
cliente, nombre del cliente y numero de �rdenes). */
SELECT CAST(table_name as varchar)  FROM INFORMATION_SCHEMA.TABLES

go
create view NumOrders
as
select OrderID, CustomerID, ContactName,Quantity from Customers,[Order Details]
	where CustomerID= Customers.CustomerID
go

select * from NumOrders

/*7. Usando la vista del punto 6, crear un procedimiento almacenado que me
devuelva el n�mero de �rdenes para un cliente especifico.*/
go
create procedure  NumOrdersClientEspeci
	@nombre varchar(50)= 'Fran Wilson'
	as  
	select OrderID, CustomerID, ContactName,Quantity 
		from Customers,[Order Details]
			where CustomerID= Customers.CustomerID and
			ContactName like @nombre
go

execute NumOrdersClientEspeci 